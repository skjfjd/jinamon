package list;

import java.util.ArrayList;
import java.util.List;

import charfactory.person.Person;



public class MainClass {

	

	

	public static void main(String[] args) {
		
		Person Gun = null;
		Person Sword = null;
			
		
		
		List<Person> l = new ArrayList<>();
		l.add(new Person());
		
		l.add(Gun);
		l.add(Sword);
		
		
		
		
		
		
		
		
		
		
		
	}

}
