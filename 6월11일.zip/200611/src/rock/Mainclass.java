package rock;

public class Mainclass {

	
	public static void main(String[] args) {
	
		new Rps();
}
}
