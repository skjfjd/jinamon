package rock;

import java.awt.Button;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

public class Rps extends Frame implements WindowListener ,ActionListener {
	Label label;
	Button button1, button2, button3, button4, button5, button6;
	
	
	
	
	public Rps() {
		
		
		label = new Label("가위 바위 보 세상");
		label.setBounds(200, 100, 100, 30);
		label.setBackground(Color.pink);
		add(label);
		
		button1 = new Button();
		button1.setLabel(" 가위 ");
		button1.setBounds(50, 200, 100, 50);
		button1.addActionListener(this);
		add(button1);
		
		button2 =new Button();
		button2.setLabel(" 바위 ");
		button2.setBounds(200, 200, 100, 50);
		button2.addActionListener(this);
		add(button2);
		
		button3 = new Button();
		button3.setLabel(" 보 ");
		button3.setBounds(350, 200, 100, 50);
		button3.addActionListener(this);
		add(button3);
		
		button4 =new Button();
		button4.setLabel(" Player ");
		button4.setBounds(150, 300, 100, 50);
		button4.addActionListener(this);
		add(button4);
		
		button5 = new Button();
		button5.setLabel(" Computer ");
		button5.setBounds(300, 300, 100, 50);
		button5.addActionListener(this);
		add(button5);
		
		button6 = new Button();
		button6.setLabel(" 결과는 : ");
		button6.setBounds(100, 400, 350, 70);
		button6.addActionListener(this);
		add(button6);
		
		
		
		
		
		setLayout(null);
		setSize(640, 480);
		setLocation(0, 0);
		setVisible(true);
		addWindowListener(this);
		
		
	}
	@Override
	public void windowActivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowClosed(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowClosing(WindowEvent e) {
		// TODO Auto-generated method stub
		
		System.exit(0);
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowIconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Button btn = (Button)e.getSource();
		String btnTitle =btn.getLabel();
		if(btnTitle.contentEquals(" 가위 ")) {
			label.setText(" 가위 ");
		}
		else if(btnTitle.contentEquals(" 바위 ")) {
			label.setText(" 바위 ");
		}
		else if(btnTitle.contentEquals(" 보 ")) {
			label.setText(" 보 ");
		}
		else if(btnTitle.contentEquals(" Player ")) {
			label.setText(" Player ");
		}
		else if(btnTitle.contentEquals(" Computer ")) {
			label.setText(" Computer ");
		}
		else if(btnTitle.contentEquals(" 결과는 : ")) {
			label.setText(" 결과는 : ");
		}
	}

}
