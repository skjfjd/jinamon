package animal;

public class Cat  implements Animal{

	@Override
	public void printDescript() {
System.out.println("야옹이");		
	}
	public void catMethod() {
		System.out.println("야옹 야옹");
	}
}
