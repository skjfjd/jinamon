package animal;

public interface Animal {

	
	public void printDescript();
	
	
}

