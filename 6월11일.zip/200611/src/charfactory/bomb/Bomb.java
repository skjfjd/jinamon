package charfactory.bomb;

public interface Bomb {

	public void drawBomb();
}
