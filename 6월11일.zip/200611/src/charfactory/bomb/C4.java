package charfactory.bomb;

public class C4 implements Bomb {

	@Override
	public void drawBomb() {
		System.out.println("폭탄 : C4 ");	
	}

}
