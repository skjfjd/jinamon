package charfactory.weapon;

public interface Weapon {
	
	public void drawWeapon();

}
