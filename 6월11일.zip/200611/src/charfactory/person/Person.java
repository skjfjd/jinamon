package charfactory.person;

import charfactory.bomb.Bomb;
import charfactory.types.AbstractItem;
import charfactory.weapon.Weapon;

public class Person {

	

		
		public Weapon m_Weapon;
		public Bomb m_bomb;
		
		public void create(AbstractItem ai) {
			
			m_Weapon = ai.createWeapon();
			m_bomb = ai.createBomb();
			
		}
	
}
