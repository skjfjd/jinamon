package charfactory;

import charfactory.person.Person;
import charfactory.types.Atype;

public class MainClass {
	
		public static void main(String[] args) {
	
			
			Person char1 = new Person();
			char1.create(new Atype());
			
			char1.m_Weapon.drawWeapon();
			char1.m_bomb.drawBomb();
}
		
}
