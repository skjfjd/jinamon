package charfactory.types;

import charfactory.bomb.Bomb;
import charfactory.bomb.Dynamite;
import charfactory.weapon.Gun;
import charfactory.weapon.Weapon;

public class Atype implements AbstractItem {

	@Override
	public Weapon createWeapon() {
		return new Gun();
		
	}

	@Override
	public Bomb createBomb() {
		return new Dynamite();
		
	}

}
