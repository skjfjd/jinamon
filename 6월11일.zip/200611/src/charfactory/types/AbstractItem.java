package charfactory.types;

import charfactory.bomb.Bomb;
import charfactory.weapon.Weapon;

public interface AbstractItem {

public Weapon createWeapon();
public Bomb createBomb();
		
	
	
}
