package charfactory.types;

import charfactory.bomb.Bomb;
import charfactory.bomb.C4;
import charfactory.weapon.Sword;
import charfactory.weapon.Weapon;

public class Btype implements AbstractItem  {

	@Override
	public Weapon createWeapon() {
		return new Sword();
		// TODO Auto-generated method stub
		
	}

	@Override
	public Bomb createBomb() {
		return new C4();
		// TODO Auto-generated method stub
		
	}

}
