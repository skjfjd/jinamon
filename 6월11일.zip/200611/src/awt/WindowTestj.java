package awt;

import javax.swing.JFrame;

public class WindowTestj  extends JFrame{

	
	public WindowTestj() {
		//진하 두둥등장
		setSize(800,600);
		setLocation(200, 100);
		
		setVisible(true); //시각화
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}
	
}
