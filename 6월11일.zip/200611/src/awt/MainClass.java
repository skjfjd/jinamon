package awt;

public class MainClass {
	
	
		public static void main(String[] args) {
	
			/*
			 	Application > App
			 	
			 	자동화 기능 > Application( C#)
			 	Web > editor
			  
			  	AWT , Swing > User Interface  (UI)
			  	
			  	Abstract Window Toolkit (AWT) == Android
			  	button , label ,textField..
			  	
			  	Application <==> Database
			  				JDBC
			  				
			  
			 */
			
			//new WindowTest();
			
			//new WindowTest1();
			new WindowTestj();
}
}
