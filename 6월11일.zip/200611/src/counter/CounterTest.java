package counter;

import java.awt.Button;
import java.awt.Frame;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JOptionPane;

public class CounterTest extends Frame  implements WindowListener , ActionListener{

	
	Label label;
	Button button1 , button2, button3;
	
	public CounterTest() {
		setLayout(null);
		
		
		label = new Label("0");
		label.setBounds(100, 100, 300, 30);
		add(label);
		
		button1 = new Button();
		button1.setLabel(" + button ");
		button1.setBounds(100, 160, 150, 30);
		button1.addActionListener(this);
		add(button1);
		
		button2 = new Button();
		button2.setLabel(" - button ");
		button2.setBounds(300, 160, 150, 30);
		button2.addActionListener(this);
		add(button2);
		
		
		button3 = new Button();
		button3.setLabel(" reset ");
		button3.setBounds(200, 300, 150, 30);
		button3.addActionListener(this);
		add(button3);
		
		setSize(640,480);
		setLocation(0,0);
		
		setVisible(true);
		addWindowListener(this);
		
		
		
	}
	
	
	
	
	
	@Override
	public void windowActivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowClosed(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowClosing(WindowEvent e) {
		// TODO Auto-generated method stub
		System.exit(0);
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowIconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}
		




	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Button btn = (Button)e.getSource();
		String btnTitle = btn.getLabel();
		if(btnTitle.contentEquals(" + button ")) {
			
			
			
		label.setText(String.valueOf(Integer.parseInt(label.getText())+1));
		}
		else if(btnTitle.contentEquals(" - button ")) {
			
		if(Integer.parseInt(label.getText())<=0) {
			JOptionPane.showMessageDialog(null, "0보다 아래로 못내려감");
			return;
		}
		label.setText(String.valueOf(Integer.parseInt(label.getText())-1));
		}
		else if(btnTitle.contentEquals(" reset " )) {
				
			label.setText("0");
		}
		
		
		
	}

}
