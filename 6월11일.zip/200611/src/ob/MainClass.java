package ob;

import observer.Observer1;
import observer.Observer2;

public class MainClass {

	public static void main(String[] args) {

		/*
		  Observer : 감시 , 정찰 감시자 패턴 > Class 감시
		  			
		  
		  
		  
		 */
		
		MyClass mcls = new MyClass();
		
		//감시자 추가
		
		mcls.addObserver(new Observer1());
		mcls.addObserver(new Observer2());
		
		
		mcls.setId("abc123");
		mcls.setPassword("au1004");
		
		mcls.notifyObservers(mcls.getPassword());
	}

}
