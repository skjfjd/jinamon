package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import db.DBClose;
import db.DBConnection;
import dto.MemberDto;

public class MemberDao {
	
	private static MemberDao dao =null;	
	
	private MemberDao() {
		
	}
	
	
	public static MemberDao getInstance() {
		if(dao==null) {
			dao = new MemberDao();
			
		}
		return dao;
		}
	public boolean getId(String id) {
		
		String sql = "SELECT ID"
				+ " FROM MEMBER"
				+ " WHERE ID= ?";	
		
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		boolean findid = false;
		
		
		
		try {
			conn = DBConnection.getConnection();
			
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, id);
			
			rs=psmt.executeQuery();
			
			if(rs.next()) {
				findid=true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBClose.close(psmt, conn, rs);
		}
		return findid;
	
	}
	public boolean addMember(MemberDto dto) {
		String sql = "INSERT INTO MEMBER(ID , PWD, NAME ,EMAIL,AUTH)"
				+ "VALUES(?,?,?,?,3)";
		Connection conn = null;
		PreparedStatement psmt = null;
		
		System.out.println("sql : "+ sql);
		
		int count =0;
		
	
		try {
			conn= DBConnection.getConnection();
			
			psmt= conn.prepareStatement(sql);
			psmt.setString(1, dto.getId());
			psmt.setString(2, dto.getPwd());
			psmt.setString(3, dto.getName());
			psmt.setString(4, dto.getEmail());
			
			count = psmt.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBClose.close(psmt, conn, null);
		}
		
		return count>0?true:false;
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
