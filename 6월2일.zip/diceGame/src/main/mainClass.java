package main;

import game.GamePlay;

public class mainClass {

	public static void main(String[] args) {
		
	//	GamePlay gp = new GamePlay();		
	//	gp.gamePlay();
		
	//	(new GamePlay()).gamePlay();
		
		new GamePlay();
	}

}





