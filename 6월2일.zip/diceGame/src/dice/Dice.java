package dice;

public class Dice {

	private int number;
	
	public void diceRamdom() {
		number = (int)(Math.random() * 6) + 1;	// 1 ~ 6 // number 는 랜덤 주사위로 바뀜
	}

	public int getNumber() {
		return number; // 게터 를 이용하여 private 이 되있어도 외부에서 number  접근 가능
	}
	
	
}
