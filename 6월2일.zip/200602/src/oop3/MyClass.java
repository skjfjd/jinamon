package oop3;

public class MyClass {
		//class member variable
	private int number =30;
	private String name="송진하";
	
	// class memeber method
	//setter
	/*public void setNumber(int newNumber) {
		number = newNumber;
	}
	public int getNumber() {
		return number;
	}*/
	
	public void func() { //처리
		
	}
	public MyClass getThis() {
		return this;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) { 	//this < 매개변수 0번째 존재하고 있는 자기자신의 참조
		this.number = number;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void method() {
		
	}
}
