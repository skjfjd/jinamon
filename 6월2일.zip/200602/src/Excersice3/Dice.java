package Excersice3;

import java.util.Scanner;

public class Dice {
	int r_num1;
	int r_num2;
	int batting;
	int coin;
	

	public void init() {
		coin =20;
		random();
		int sum1= r_num1;
		int sum2= r_num2;
		System.out.println("주사위 1 : " + sum1);
		System.out.println("주사위 2 : " + sum2);
		
	}
		public void random() {
			Scanner sc = new Scanner(System.in);
			int sum=0;
		
		 
			 r_num1 = (int)(Math.random()*6)+1;
			 r_num2 = (int)(Math.random()*6)+1;
			sum=r_num1 +r_num2;
		}
		
			
		public void userInput() {
				Scanner sc = new Scanner(System.in);
				coin =20;
				System.out.println("배팅할 코인의 수 >> ");
				int batting = sc.nextInt();
				coin = coin - batting;
				System.out.println("두 주사위의 합은 >> ");
				int c = sc.nextInt();
			int sum = r_num1+r_num2;
			
			if(c == sum) {	
			if(sum==3 || sum== 11) {
				batting = batting * 18;
			}else if(sum==4 || sum== 10) {
				batting = batting * 12;
			}else if(sum==5 || sum== 9) {
				batting = batting * 9;
			}else if(sum==6 || sum== 8) {
				batting = batting * 7;
			}else if(sum==7) {
				batting = batting * 6;
			} 
				System.out.println("축하합니다 ");
					coin = coin+batting; }
		else {
			
		} System.out.println("아쉽습니다.");
			

		}
		public void result() {
			System.out.println("주사위 1 : " + r_num1);
			System.out.println("주사위 2 : " + r_num2);
			
			int sum= r_num1+r_num2;
			System.out.println("합계 :" + sum);
			System.out.println("현재 coin :" + coin);
			
				
		}		
}
