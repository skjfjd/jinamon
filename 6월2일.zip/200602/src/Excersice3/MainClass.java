package Excersice3;

public class MainClass {

	public static void main(String[] args) {
			Dice d = new Dice();
			d.init();
			d.userInput();
			d.random();
			d.result();
			
	}

}
