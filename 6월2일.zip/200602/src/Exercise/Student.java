package Exercise;

public class Student {
		
	public String name;
	public int ban ;
	public int no ;
	public int kor;
	public int eng ;
	public int math ;
	public int getTotal;
	public double getAvg;
	
	public void setName(String n) {
		name= n;
	}
	public void setBan(int b) {
		ban=b;
	}
	public void setNo(int n) {
		no=n;
	}
	public void setkor(int k) {
		kor=k;
	}
	public void setEng(int e) {
		eng=e;
	}
	public void setmath(int m) {
		math=m;
	}
	public int getTotal(int k , int e , int m) {
		getTotal=(k+e+m);
		return getTotal;
		//this.kor + this.eng +this.math 가능함
	}
	public double getAvg() {
		getAvg=(double)(getTotal)/3;
		
		return getAvg;
	}
	
	
}
