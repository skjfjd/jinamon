package constructor;

public class MyClass {
	/*
	 
	  Constructor : 생성자   == method
	  				class 명과 같은 method
	  				return 값 x
	  				overload 가 가능   < 매개변수가 다른것을 의미
	  				자동호출 가능
	  				별도의 호출 불가능
	  				생략 가능하다
	  				기본값을 설정할 경우가 많다
	  				초기화는 사용 하지 않는 편이 좋다
	  destructor : 소멸자
	  
	 */
	 
	private int number;
	private String name;
	
	public MyClass() {
		System.out.println("MyClass MyClass()");
	}
	public MyClass(int number) {
		this.number = number;
		System.out.println("MyClass MyClass(int number)");
	}
	public MyClass(int number , String name) {
		this(34);
		this.number = number;
		this.name = name;
		System.out.println("MyClass MyClass(int number, String name");
	}
}
