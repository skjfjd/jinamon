package constructor;

public class MainClass {
	public static void main(String[] args) {
	
		MyClass cls = new MyClass();
		
		MyClass cls1 = new MyClass(10);
		
		MyClass cls2 = new MyClass(0, "송");
		
		
}
}
