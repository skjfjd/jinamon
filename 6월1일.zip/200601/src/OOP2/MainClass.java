package OOP2;

public class MainClass {

	public static void main(String[] args) {
		MyClass cls = new MyClass();
		
		cls.number = 1;
		cls.name = "홍길동";
		cls.age = 23;
		cls.address = "서울시";
		
			cls.func();
			cls.method();
			
		MyClass mcls = new MyClass();
		
		System.out.println(cls);
		System.out.println(mcls);
		/*
			  절차지향
			  정렬
				  1.입력
				  2.정렬처리
				  	swap
				  3.출력
				  
			객체지향
			  1.처리들
			  	입력 , 정렬 , 교환 , 출력
				순서 호출
		 */
	}

}
