package OOP2;

public class MyClass {
		//변수
		int number;
		String name;
		int age;
		String address;
	//메소드(필요한 처리에 대한 함수)
		public void func() {
			System.out.println("Myclass func()");
		}
		public void method() {
			System.out.println("Myclass method()");
		}
}
