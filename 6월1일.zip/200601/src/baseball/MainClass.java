package baseball;

public class MainClass {

	public static void main(String[] args) {
		Baseball ball = new Baseball();
		
		ball.init();
		ball.loop();
		ball.result();
	}

}
