package test;

import java.util.Scanner;

public class Random {
	int r_num[];
	int u_num[]; 
  int r;
  int number[]= new int[5];
  /*
	 1. random > 30 ~100
	 2. userInput > 1~15
	 3. random number - user number
	 4. game over
	 
	 */
  public void random() {
		boolean swit[] = new boolean[10];
		
		for (int i = 0; i < swit.length; i++) {
			swit[i] = false;	// 00000 00000
		}		
		
		int r, w;		
		w = 0; 				
		while(w < 3) {
			r = (int)(Math.random() * 70)+30;	// 0 ~ 9
			if(swit[r] == false) {
				swit[r] = true;		// 00100 00000
				r_num[w] = r + 1;			// 1 ~ 10
				w++;
			}
		}
		
		for (int i = 0; i < r_num.length; i++) {
			System.out.println(i + " : " + r_num[i]);
		}
	
	  
		  
	  
  }
}
