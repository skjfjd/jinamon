package objectorientedprograming;

import myclass.Student;
import myclass.Tv;

public class Oop {

	public static void main(String[] args) {

		/*
		  	 Object Oriented Programing
		  	 
		  	 처리 중심 > 설계중심
 
		 */
		
		// TV > 2대
		
	/*	String name[] = new String[2];  // 삼성 , 엘쥐
		int channel[] = new int[2];  //채널
		boolean power[]=new boolean[2]; // on/off
		
		name[0]= "삼성";
		name[1]= "엘쥐";
		
		channel[0] = 11;
		channel[1] = 23;
		
  		power[0] = true;
		power[1] = false; */
		/*
		  class Myclass{ class 설계
		   		변수 (member) - 접근 지정 (외부 , 내부)
		   				   		
		   		함수(메소드) - 처리
		  
		   }
		   
		   클래스명(instance) = new 클래스명();
		   Myclass cls = new Myclass();
		   		   stack      heap
		   Myclass cls = null; > 0
		 */
		
		Tv tv1 = new Tv();    //tv1 > instance(주체) : 메모리상에 존재하는 요소
		tv1.getInput("LG", 11, true);
		tv1.method();
		System.out.println();
		
		Tv tv2 = new Tv();  //tv2 > Object라고도 한다
		tv2.getInput("삼성", 12, false);
		tv2.method();
		System.out.println();
		
		//배열만을 동적할당
		Tv arrTv[] = new Tv[3]; // Tv arrTv1 ,Tv arrTv2  ,Tv arrTv3
		
		
		// 객체를 동적 할당
		for (int i = 0; i < arrTv.length; i++) {
			arrTv[i] = new Tv();
		}
		
		arrTv[0].getInput("엘지", 17, true);
		arrTv[1].getInput("sk", 18, true);
		arrTv[2].getInput("삼성", 19, true);
		
		arrTv[1].setPower(false);
		
		for (int i = 0; i < arrTv.length; i++) {
			arrTv[i].method();
		}
		String student1[][]= {
				{"홍길동" , "24" , "98" , "100"},
				{"일지매" , "21" , "80" , "90"},
				{"임꺽정" , "27" , "70" , "100"},};
		
		Student stu = new Student();
		
		stu.setName("홍길동");
		stu.setAge(24);
		stu.setEng(98);
		stu.setMath(100);
	
		stu.method();
	}

}
