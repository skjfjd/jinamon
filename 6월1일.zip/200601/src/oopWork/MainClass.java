package oopWork;

public class MainClass {

	public static void main(String[] args) {

		/*
		 원 넓이를 구할수 있는 class
		  		입력 > 출력
		  		
	 	직사각형의 넓이를 구할수 있는 class
		 */
		
		One o = new One();
		Rectangle r = new Rectangle();
		o.area();
		o.length();
		
		
		r.width();
		r.round();

	}
	

}
