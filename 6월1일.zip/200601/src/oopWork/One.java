package oopWork;



public class One {
	int num1 =10;
	final double pi= 3.14;
	double area , length;
	public void area() {
		
		
		area = num1*num1*pi;
		
		
		System.out.println("넓이 : "+ area);
		
	}
	public void length() {
		length = num1*2*pi;
		System.out.println("둘레 : "+ length);
	}
	public void rectangle() {
		
		
	}
}
