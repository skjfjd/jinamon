package oopWork;

public class Rectangle {
	int width = 10;
	int height = 20;
	int area;
	int round;
	
	public void width() {
		area= width * height;
		System.out.println("area : " + area);
		
	}
	public void round() {
		round =(width+height)*2;
		System.out.println("round :" + round);
	}
	
	
	
			/*
			 1. random > 30 ~100
			 2. userInput > 1~15
			 3. random number - user number
			 4. game over
			 
			 */
		
	}

