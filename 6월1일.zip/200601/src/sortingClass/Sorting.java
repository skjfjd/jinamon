package sortingClass;

import java.util.Scanner;

public class Sorting {
	//멤버 변수(두 가지 이상 처리(메소드)에서 접근해야 하는 경우) 
	int[] number;
	boolean updown;
	
	//처리;
	public void input() {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("정렬할 갯수 : ");
		int count = sc.nextInt();
		
		number = new int[count]; // 동적할당
		
		for (int i = 0; i < number.length; i++) {
			System.out.println((i+1) + "번째 수 : ");
			number[i]= sc.nextInt();
		}
		
		System.out.println("오름(1)/내림(2)");
		int ud = sc.nextInt();
		if(ud==1) updown=true;
		else 	  updown=false;
			
		
		
		
	}
	public void sorting() {
		for (int i = 0; i < number.length -1; i++) {
			for (int j = i+1; j < number.length; j++) {
				if(updown) {
					if(number[i]> number[j]) {
						swap(i,j);
					}
				}else {
					if(number[i]<number[j]) {
						swap(i,j);
					}
				}
			}
		}
		
	}
	public void swap(int i , int j) {
		int temp= number[i];
		number[i] = number[j];
		number[j] = temp;
	}
	public void result() {
		for (int i = 0; i < number.length; i++) {
			System.out.println(i + ":"  + number[i]);
		}
		
	}
}
