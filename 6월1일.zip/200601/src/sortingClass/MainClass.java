package sortingClass;

public class MainClass {

	public static void main(String[] args) {
		Sorting sort = new Sorting();
		
		sort.input();
		sort.sorting();
		sort.result();
	}

}
