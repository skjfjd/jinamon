package myclass;

public class Student {
	String name;
	int age;
	int eng;
	int math;
	
	public void setName(String n) {
		name = n;
	}
	public void setAge(int a) {
		age =a;
	}
	public void setEng(int e) {
		eng = e;
	}
	public void setMath(int m) {
		math = m;
	}
	
	public void getInput(String n , int a , int e , int m) {
		name = n;
		age = a;
		eng = e;
		math = m;
		
	}
	public void method() {
		  System.out.println("name  :" + name);
		  System.out.println("age  :" + age);
		  System.out.println("eng  :" + eng);
		  System.out.println("math  :" + math);
		  
	}
}
