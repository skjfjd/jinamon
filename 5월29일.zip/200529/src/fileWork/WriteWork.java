package fileWork;

import java.io.File;


public class WriteWork {

	public static void main(String[] args)  {
				/* 
				 write   외부에서 가져오는
				 String arrAtr[] = {
				 		"Hello",
				 		"안녕하세요",
				 		"HI"
				  };
				  파일명.txt 저장되는 함수
				 
				 read
				  	String strAtr[];
				  	[0] < "Hello"
				 	[1] < "안녕하세요",
				 	[2]	<  "HI"
				 */
	/*	File file = new File("d:\\tmp\\newfile.txt");
		Scanner sc = new Scanner(System.in);
		int count;
		String arrAtr[]= null;
		System.out.println("저장하고 싶은 함수 갯수는 : ");
		count = sc.nextInt();
		
		arrAtr = new String[count];
		
		for (int i = 0; i < arrAtr.length; i++) {
			arrAtr[i]= sc.next();
	
		
		
		
		FileWriter fwriter = new FileWriter(file); //파일 포인터 설정
		BufferedWriter bw = new BufferedWriter(fwriter); // 문장으로
		PrintWriter pw = new PrintWriter(bw);
		pw.print("안녕"+ "\n");
		pw.println("하이하이");
		pw.println("건강하세요");
		
		
		pw.close();*/
	}
		static void dataSave(File f , String datas[])  {
			
			File file = new File(f, null);
			
				}
				
			 
			 
			 
			 
		
		
	
			
		}
		
	

	

