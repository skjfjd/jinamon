package filewrite;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;


public class Write {

	public static void main(String[] args) throws Exception {
			//file write
		
		File file = new File("d:\\tmp\\test.txt");
		
		//한문자씩 쓰기
	/*	FileWriter fw= new FileWriter(file) ;
		fw.write("안녕하세요" + "\n" );
		fw.close();
		*/
	
		//추가 쓰기 append
		/*	FileWriter fw= new FileWriter(file) ;
			FileWriter fw = new FileWriter(file , true);
		fw.write("건강하세요"+ "\n");
		fw.close();
		*/
		
		FileWriter fwriter = new FileWriter(file); //파일 포인터 설정
		boolean b = false;
		
		BufferedWriter bw = new BufferedWriter(fwriter); // 문장으로
		PrintWriter pw = new PrintWriter(bw);
		
		pw.print("안녕"+ "\n");
		pw.println("하이하이");
		pw.println("건강하세요");
		
		pw.close();
		
	}
		
}
