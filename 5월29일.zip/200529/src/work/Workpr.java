package work;

import java.util.Scanner;

public class Workpr {

	public static void main(String[] args) {
			int num1 , num2 ;
			
			
		Scanner sc = new Scanner(System.in);
		System.out.println("숫자 입력");
		String str = sc.next();
		boolean check = false;
		
	
		
		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);
			if(c=='.') {
				check = true;
				break;
			}
		}
		if(check) {
			System.out.println("실수입니다.");
		}else {
			System.out.println("정수입니다.");
		}
		
	}

}
