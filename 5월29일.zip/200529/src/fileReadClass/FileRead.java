package fileReadClass;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileRead {

	public static void main(String[] args) {
		//file read
		File file = new File("d:\\tmp\\test.txt");
		
		try {
			FileReader fr = new FileReader(file);
			
			String str = "";
			//한문자씩 읽어 들인다
			
			int c = fr.read();
			while(c != -1) {
				System.out.println((char)c);
				str =str +(char)c;
				c=fr.read();
			} System.out.println(str);
			//문장으로 읽어 들인다
			BufferedReader br= new BufferedReader(fr);
			
			String str1 =br.readLine();
			while(str1 !=null) {
				System.out.println(str1);
				str1=br.readLine();
				
			}br.close();
			
			
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}catch (IOException e ) {
			e.printStackTrace();
		}
	}

}
