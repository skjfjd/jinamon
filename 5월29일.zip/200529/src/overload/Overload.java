package overload;

public class Overload {

	public static void main(String[] args) {
		
		/*
		  Over Load : 함수(메소드)명은 같고
		   			    매개변수(인수 , 인자)의 자료형이나 인수의 갯수가 다른 것을 의미한다.
		   			    
		  image drawing > 알파(투명) , 불투명 
		  				   RGBA      RGB
		  imageDraw(int x , int y , int a)
		  
		  imageDraw(int x , int y)
		 */
		
		int num1 = Integer.parseInt("123");
		int num2= Integer.parseInt("1010", 2) ;
			System.out.println("num1 : " + num1);
			System.out.println("num2 : " + num2);
		
		/*
		  unsigned = 0~255  //언사인드 부호비트 사용 안하고 마이너스 사용 안함
		  singed byte = -128 ~ 127 
		 */
			funcName();
			funcName('A');
			funcName(123);
			funcName('B', 12);
			funcName(123, 'c');
	}

	static void funcName() {
		System.out.println("funcName() 호출");
	}

	static void funcName(char c) {
		System.out.println("funcName(char c) 호출");
	}
	static void funcName(int i) {
		System.out.println("funcName(int i) 호출");
	}
	static void funcName(char c , int i) {
		System.out.println("funcName(char c , int i) 호출");
	}
	static void funcName(int i , char c) {
		System.out.println("funcName(int i , char c) 호출");  //오버로드는 리턴값 x
		
}
}
