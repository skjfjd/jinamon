package exception;

public class Exception {

	public static void main(String[] args) {
			
		
		/*
			Exception : 예외     !=에러	
				 
			baseball > 1 2 3 ~ 10 > 'A' > 65	
			
			number > format 1 ~ 3 >'A'
			array > index number [3] > array[3]
			class > Scanner 못 찾는 경우 
			file > 없을 경우
			
			try{
			 예외가 나올수 있는 소스1
			 예외가 나올수 있는 소스2
			}catch(예외클래스1 e){
			     	메시지
			}catch(예외클래스 2 e){
			  		메시지
			}finally{ (생략가능)   
			   // 무조건 실행
			   // 뒤처리	
			      파일 close
			   Database 원상복구 rollback > undo
			}   
			   
			   
			   
		 */
/*	int array[]= {1,2,3};
		System.out.println("프로그램 시작");
	try {	
		for (int i = 0; i < 4; i++) {
		System.out.println(array[i]);
	}
	
	}catch (ArrayIndexOutOfBoundsException e) {
		System.out.println("배열 범위 초과");
	//	e.printStackTrace();
	//	System.out.println(e.getMessage());
		return; //리턴을 해도 파이널리는 무조건 실행  프로그램 끝은 실행 안됨
	}catch (NumberFormatException e){ //문자
		e.printStackTrace();
	}finally {
		System.out.println("finally 무조건 실행");
	}
		
		System.out.println("프로그램 끝");*/
		
		func();
		func1();
	}
	
	
	static void func()throws ArrayIndexOutOfBoundsException {
		int array[]= {1,2,3};
			
		for (int i = 0; i < 4; i++) {
			System.out.println(array[i]);
		}
		}
		static void func1()throws ArrayIndexOutOfBoundsException {
			int array[]= {1,2,3};
				
			for (int i = 0; i < 4; i++) {
				System.out.println(array[i]);
	}
	
		}
}
