--1��

select  employee_id , last_name , job_id ,salary
from employees
where salary >=3000;

--2��

select  employee_id , last_name ,  job_id , salary , DEPARTMENT_ID
from employees
WHERE JOB_ID = 'ST_MAN';


SELECT
    *
FROM(SELECT*
FROM EMPLOYEES);  --���� ���� 

--3��
select  employee_id , last_name ,  job_id , salary , HIRE_DATE , DEPARTMENT_ID
from employees
WHERE HIRE_DATE > TO_DATE('19810101'); 

--4��
select   last_name ,  job_id , salary ,  DEPARTMENT_ID
from employees
WHERE SALARY BETWEEN 3000 AND 5000;
--WHERE SALARY >=3000 AND SALARY <=5000;

--5��
select employee_id ,  last_name ,  job_id , salary ,  HIRE_DATE
from employees
WHERE employee_id  in(145,152,203);

--6��
select employee_id ,  last_name ,  job_id , salary ,  HIRE_DATE , DEPARTMENT_ID
from employees
WHERE HIRE_DATE  LIKE '05%';
-- WHERE HIRE_DATE >= '05/01/01' AND HIRE_DATE <=05/12/31';

--7��
select employee_id ,  last_name ,  job_id , salary ,  HIRE_DATE , NVL( COMMISSION_PCT,0.0), DEPARTMENT_ID
from employees
WHERE COMMISSION_PCT  IS NULL;

--8��
select employee_id ,  last_name ,  job_id , salary ,  HIRE_DATE ,  DEPARTMENT_ID
from employees
WHERE SALARY>=1100 AND JOB_ID = 'ST_MAN';

--9��
select employee_id ,  last_name ,  job_id , salary ,  HIRE_DATE ,DEPARTMENT_ID
from employees
WHERE SALARY >=10000 OR JOB_ID = 'ST_MAN';  --  or �̴ϱ� st���� �ƴϴ��� �ٸ� �Ŵ����鵵 ���� ����

--10��
select employee_id ,  last_name ,  job_id , salary  ,   DEPARTMENT_ID
from employees
WHERE  JOB_ID NOT IN ('ST_MAN' , 'SA_MAN' , 'SA_REP');

--11��
select employee_id ,  last_name ,  job_id , salary 
from employees
WHERE   JOB_ID= 'AD_PRES' AND SALARY>=12000 OR JOB_ID = 'SA_MAN';

--12��
SELECT
    *
FROM EMPLOYEES
WHERE JOB_ID = 'AD_PRES' OR JOB_ID = 'SA_MAN' AND SALARY >= 12000;
