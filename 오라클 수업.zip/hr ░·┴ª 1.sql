--1��
select *from employees;

--2��
desc employees;

--3��

select employee_id ,first_name , salary , job_id
from employees;

--4��
select first_name , salary ,salary+300
from employees;

--5��
select employee_id , first_name  , salary , salary*commission_pct   ,salary+(salary*commission_pct) 
from employees;

--6�� 
select last_name ,salary
from employees;

--7��
select last_name as name , salary*12 as "Annual Salary"

from employees;

--8��
select first_name || ' ' || job_ID Employees 
from employees;

--9��
select '"'|| last_name ||'is a '|| job_id ||'"' as "Employees Details"
from employees;

--10��
select '"'|| last_name || ': 1 Year salary = '  || salary* 12 || '"' as "�̸��� ����"
from employees;

--11��

select DISTINCT job_ID
from employees;
