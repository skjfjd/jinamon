package staticClass;

public class MyClass {

	 int memNum;   //member variable
	static int staticVar; //static variable
	
	public int getMemNum() {
		return memNum;
	}

	public void setMemNum(int memNum) {
		this.memNum = memNum;
	}
	
	public void method() {
		memNum =memNum+1;     // 객체가 바뀌었을떄  초기값으로 다시 리턴
		System.out.println("memNum :" + memNum); 
		staticVar = staticVar+1; // 객체가 바뀌어도 값이 저장되어 있던 값에서  ++ 하거나 -- 할수있다
		System.out.println("staticVar : " + staticVar);
	}
	public static void staticMethod() { //class method
		System.out.println("MyClass staticMethod() 호출");
		
		// 접근 못하는 요소   
		//this , super 접근을 못한다.
	}
	
	
	
}
