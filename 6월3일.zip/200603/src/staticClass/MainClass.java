package staticClass;

public class MainClass {

	public static void main(String[] args) {

		/*
		 
		  static ==정적 -> 유지상태
		 
		  stack heap static sys
		   i
		 */
		int i; // local(지역) 변수
		
		{
			int j ; // local 변수(지역) ==auto
			j=12;
		}
		
		 MyClass cls = new MyClass();
		 //     stack       heap
		 
		 int m = cls.getMemNum();
		 System.out.println( "m : " + m);
		 
		cls.method();
		cls.method();
		cls.method();
		MyClass cls2 = new MyClass(); // 인스턴스가 달라도  static 변수는 계속 +1 씩 하는가 반면 static 이 아닌 변수는 다시 처음으로 돌아간다 4 > 1
		
		cls2.method();
		
		MyClass.staticMethod();
		
		Member mem = new Member();
		
		
		mem.init();
		mem.random();
		mem.input();
		
		Member mem2 = Member.getInstance();
		
		
		
		
		
		
		
	}

}
