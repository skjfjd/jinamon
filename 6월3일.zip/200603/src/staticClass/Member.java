package staticClass;

public class Member {

	public Member() {
		System.out.println("Member()");
	}
	public void init(){
		System.out.println("Member init()");
	}
	public void random() {
		System.out.println("Member random()");
	}
	public void input() {
		System.out.println("Member input()");
	}	//스태틱 쓰고 클래스 이름 가능
	public static Member getInstance() {
		Member m = new Member();  //먼저 객체 생성해주고 출력은 메인함수에서  리턴 필수
		m.init();
		m.random();
		m.input();
		
		return m;
	}
}
