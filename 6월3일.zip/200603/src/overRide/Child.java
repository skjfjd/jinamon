package overRide;

public class Child extends Parant {

	
	public Child() {
		
	}
	
	//Over Ride 실시간 method
	//OVer Ride 의 목적 > 관리 용이
	public void method() {
		System.out.println("Child method()");
	//	super.method(); 
	}
	
	public void func() {
		System.out.println("Child func()");
	}
	
	
	
}
