package overRide;

public class MainClass {

	public static void main(String[] args) {
		
	//	Child c = new Child();
	//	c.method();
		
		Parant p = new Child();
		p.method();  // child 메소드 호출됨
	}
	

}
