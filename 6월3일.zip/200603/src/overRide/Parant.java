package overRide;

public class Parant {

	
	public Parant() {
		
	}
	public Parant(int number) {
		
	}
		/*
		 Over Ride : 상속 받은 후에 상속 받은 클래스(자식 클래스)에서 고쳐 기입함을 의미한다 
		  
		  
		 */
	public void method() {
		System.out.println("Parant method()");
	}
}
