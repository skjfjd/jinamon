package purpose;

public class ChildOne extends Parant {

	
	public ChildOne() {
		
	}
	
	public void method() {
		System.out.println("ChildOne method()");
	}
	public void  func() {
		System.out.println("ChildOne func()");
	}
}
