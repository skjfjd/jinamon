package purpose;

public class ChildTwo extends Parant{

	public ChildTwo() {
		
	}
	public void method() {
		System.out.println("ChildTwo method()");
	}
}
