package purpose;

public class MainClass {

	public static void main(String[] args) {

	/*	
		ChildOne one = new ChildOne();
		ChildTwo two = new ChildTwo();
		
		one.method();
		two.method();
		
		
		Parant pone = new ChildOne();
		Parant ptwo = new ChildTwo();
		
		pone.method();
		ptwo.method();
		
		
		//10명
		//lady
		ChildOne lady[] =new ChildOne[10];
		
		//man
		ChildTwo man[]= new ChildTwo[10];
		
		lady[0] = new ChildOne();
		man[0] = new ChildTwo();
		
		
		Parant human[] = new Parant[10];
		
		human[0] = new ChildOne();
		human[1] = new ChildTwo();
		
		for (int i = 0; i < human.length; i++) {
			human[i].method();
		}
		*/
		Parant p1 = new ChildOne();  //부모 클래스는 상속 받는 자식 클래스를 모두다 편리하게 불러올수 있다.
		Parant p2 = new ChildTwo();
		
		p1.method();
		p2.method();
		
		ChildOne co = (ChildOne)p1; //부모 생성자에선 펑크를 안만들어서  p1 인스턴스가  ChildOne으로 캐스팅 변환을해서 ChildOne 으로 인식이 되어 func 호출됨
		co.func();
		
		((ChildOne)p1).func();
		
	}

}
