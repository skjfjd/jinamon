package purpose;

public class Parant {
			
	
	public Parant() {
		
	}
	
	public void method() {
		System.out.println("Parant method()");
	}
}
