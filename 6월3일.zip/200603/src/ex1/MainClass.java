package ex1;
class Parent {
	int x=100;
public	Parent() { //2
	this(200);
} 
public	Parent(int x) {   //1
	this.x = x;
}
public 	int getX() {
	return x;
}
	
}
class Child extends Parent {
	int x = 3000;
	public	Child() {//4
			this(1000);
	}		
		
	public	Child(int x) { //3 
		this.x = x;
	}


}
public class MainClass {

	public static void main(String[] args) {

		Child c = new Child();
		System.out.println("x="+c.getX());

		
	}

}
