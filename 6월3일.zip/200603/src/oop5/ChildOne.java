package oop5;

public class ChildOne extends Parant {

	
	public void method() {
		System.out.println("ChildOne  Over Ride method()");
	}
	public void oneMethod() {
		System.out.println("ChildOne oneMethod()");
	}
}
