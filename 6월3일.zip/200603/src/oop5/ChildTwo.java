package oop5;

public class ChildTwo extends Parant {

	
	public void method() {
		System.out.println("ChildTwo Over Ride method()");
	}
}
