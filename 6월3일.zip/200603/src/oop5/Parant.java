package oop5;

public class Parant {

	public void method() {
		System.out.println("Parant method()");
	}
}
