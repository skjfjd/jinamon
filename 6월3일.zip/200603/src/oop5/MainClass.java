package oop5;

public class MainClass {

	public static void main(String[] args) {

		Parant p = new Parant();
		Object o = new Parant();
		
		Parant p1 = (Parant)o;
		p1.method();
		/*
		 	instanceOf
		 	: 상속 받은 Object를 부모 클래스의 instance로 생성
		 	ChildOne	   >> Parant	
		 	ChildTwo       >> Parant
		 	
		 	생성된 instance에  어떤 자식클래스가 생성 되었는지 판별할 수 있는 제어자
		  
		 */
		
		Parant arrPar[] = new Parant[3];
		arrPar[0] = new ChildOne();
		arrPar[1] = new ChildTwo();
		arrPar[2] = new ChildOne();
		
		for (int i = 0; i < arrPar.length; i++) {
			arrPar[i].method(); //오버 라이드된 메소드
	
		if(arrPar[i] instanceof ChildOne) {
			ChildOne one = (ChildOne)arrPar[i];
			one.oneMethod();  // 오버라이드 된 메소드가 아님
		}
		}
	}

}
