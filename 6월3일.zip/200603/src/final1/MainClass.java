package final1;

public class MainClass {
public static void main(String[] args) {
	
	
		// final : 제약
	
			/*
			 
			 변수, 메소드 ,클래스
			 
			 
			 */
	
	final int number=10;  // final 변수 >  상수(대입)
	final int MEMBER_NUMBER=100; 
}
}
 class superClass{ //상속 금지
	int number;
	
	public superClass() {
		
	}
	public void method() { // Over Ride 금지
		
	}
}

class thisClass extends superClass{ // 슈퍼클래스 상속 못함
	public void method() {  //Over RIde
		
	}	
}