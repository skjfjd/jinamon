package oop4;

public class Parant {
	
	private int number;
	protected String name;
	//protected 자식클래스에서는 접근 허용 하지만 외부 클래스에선 접근 차단한다
	
	public Parant() { // 기본 생성자 
		
		System.out.println("Parant Parant");
	}
public Parant(int number) {   //super 를 이용하면  위에꺼말고 이게 실행됨
		this.number = number;
		System.out.println("Parant (int nuber)");
	}


	public void Parant_method() {
		System.out.println("Parant method");
		System.out.println("number =" + number);
	}
}
