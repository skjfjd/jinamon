package oop4;

public class Child extends Parant {

	public Child() {  //기본생성자는 무조건 만들기
		// super :부모클래스의 reference(pointer==주소)
		// this  : 자기자신의 참조
		super(2); // 슈퍼는 항상 맨위에
		System.out.println("Child Child");
	}
	public Child(int num) {
		
		super(num);
	}
	public void func() {
		name="송진하";
	}
}
