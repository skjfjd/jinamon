package ex2;

public class Dropship extends Unit {
	
	public	int x, y=0; 
	/*	public void move(int x, int y) {
			
			   }
		public	void stop() {  
			
		}*/
		public	void load() {  
			System.out.println("선택된 대상을 태운다.");
		}
		public	void unload() { 
		System.out.println("선택된 대상을 내린다.");	
		}

		
}
