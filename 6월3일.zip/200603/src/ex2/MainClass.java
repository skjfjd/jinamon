package ex2;

public class MainClass {

	public static void main(String[] args) {
		Unit m = new Marine();
	  	Unit t = new Tank();
	  	Unit d = new Dropship();
	  	
	  	Unit un[] = new Unit[3];
	  	
	  	un[0] = new Marine();
	  	un[1] = new Dropship();
	  	un[2] = new Tank();
	  	 
	  	un[0].move(100, 100);
	  	un[1].move(200, 200); 
	  	un[2].move(300, 300);
	  	un[0].stop();
	  	un[1].stop(); 
	  	un[2].stop();
	  	for (int i = 0; i < un.length; i++) {
	  	
		
		if(un[i] instanceof Marine) {
			Marine one  = (Marine)un[i];
			one.stimPack();
		}else if(un[i] instanceof Tank) {
				Tank two = (Tank)un[i];
				two.changeMode();
			}else if(un[i] instanceof Dropship){
				Dropship th = (Dropship)un[i];
				th.load();
				th.unload();
			}
		
	  	}
	}

}
