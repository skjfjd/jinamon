package ex2;

public class Marine extends Unit {
	

	public	int x, y=0; // 현재 위치
	/*public	void move(int x, int y) { 
		
	}
	public	void stop() { 
		
	}*/
	public	void stimPack() { 
		System.out.println("스팀팩을 사용한다");
	}

		
}
