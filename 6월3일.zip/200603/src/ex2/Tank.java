package ex2;

public class Tank extends Unit {
	
	public	int x, y=0; // 현재 위치
	/*public	void move(int x, int y) { 
	
	}
	public	void stop() {
		
	}*/
	public	void changeMode() { 
		System.out.println("공격모드로 변환한다");
	}

	
}
