package ex2;

public class Unit {
		
	public Unit() {
		
	}
		int x,y;
	public void move(int x, int y) {
		System.out.println("x : " + x + "y : " + y);
	}
	public	void stop() { 
		System.out.println(" 멈춰");
		
	}

}

