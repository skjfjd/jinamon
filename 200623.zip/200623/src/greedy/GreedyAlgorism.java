package greedy;

import java.util.Scanner;

public class GreedyAlgorism {

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		
		int num1 , num2 = 0;
		int changeMoney;
		System.out.print("지불할 금액 : ");
		num1= sc.nextInt();
		System.out.print("결제 금액 : ");
		num2 = sc.nextInt();
		
		changeMoney = num1-num2;
		
		
		System.out.println("거스름돈 : " + changeMoney);
		 int m100000000 = changeMoney %50000000;
		 int m50000000 = (changeMoney %50000000) /10000000; 
		 int m10000000 = (changeMoney %10000000) /5000000;
		 int m5000000 = (changeMoney % 5000000) / 1000000;
		 int m1000000 = (changeMoney % 1000000) / 500000;
		 int m500000 = (changeMoney % 500000) / 100000;
		 int m100000 = (changeMoney % 100000) / 50000;
		 int m50000 = (changeMoney % 50000) / 10000;
		 int m10000 = (changeMoney %10000) /5000;
		 int m5000 = (changeMoney % 5000) / 1000;
		 int m1000 = (changeMoney % 5000) / 1000 ;
		 int m500 =  (changeMoney % 1000) / 500 ;
		 int m100 = (changeMoney % 500)/ 100;
		 int m50 = (changeMoney % 100) / 50;
		 int m10 = (changeMoney % 50) / 10;
		 if(changeMoney <m100000000) {
			 System.out.println("5천만원권 : " + m50000000 + "장");
		 }
		
		 System.out.println("1천만원권 : " + m10000000 + "장");
		 System.out.println("500만원권 : " + m5000000 + "장");
		 System.out.println("100만원권 : " + m1000000 + "장");
		 System.out.println("50만원권 : " + m500000 + "장");
		 System.out.println("10만원권 : " + m100000 + "장");
		 System.out.println("5만원권 : " + m50000 + "장");
		 System.out.println("1만원권: " + m10000 + "장");
		 System.out.println("5천원권 : " + m5000 + "장");
		 System.out.println("1천원권 : " + m1000 + "장");
		 System.out.println("오백원 : " + m500 + "개");
		 System.out.println("백원 : " + m100 + "개");
		 System.out.println("오십원 : " + m50 + "개");
		 System.out.println("십원: " + m10 + "개");
		 
		 
		 
		 
	}

}
