package WindowChange2;

public class MainClass {

	public static void main(String[] args) {

		SingletonClass.getInstance().one.setVisible(true);
		
		
	}

}
