package WindowChange2;

import java.awt.Color;

import javax.swing.JFrame;

public class WindowTwo extends JFrame{

	
	public WindowTwo() {
		setLayout(null);
		
		setBounds(0, 0, 800, 600);
		setVisible(false);
		setBackground(Color.blue);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
	}
}
