package ex;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class BaseballTwo extends JFrame implements ActionListener{
	
	JTextField textField; // 텍스트를 만들어 주는 영역?
	JTextArea textArea;	 //여러줄의 문자열을 입력 가능하게하는
	
	
	JButton btn1 ,btn2;
	
	
	public BaseballTwo() {
		super("insert");
		
		JPanel panel = new JPanel();
		
		textArea = new JTextArea();
		textArea .setLineWrap(true);
		
		JScrollPane scrpane = new JScrollPane(textArea);
		scrpane.setPreferredSize(new Dimension(400,300));
		panel.add(scrpane);
		
		JPanel botpan = new JPanel();
		
		textField =new JTextField(20);
		
		btn1 = new JButton("menu");
		
		
		
			
			
			
			
		setBounds(0, 0, 800, 600);
		setVisible(false);
		setBackground(Color.blue);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void  insert() {
		
		
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}
