package ex;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class BaseballOne extends JFrame implements ActionListener{

	JLabel frontLabel;
	JLabel label[];
	JButton button[];
	
	public	BaseballOne() {
		super("Baseball");
		setLayout(null);
			frontLabel = new JLabel("menu");
		frontLabel.setBounds(35, 30, 500, 100);
		frontLabel.setHorizontalAlignment(JLabel.CENTER);
		add(frontLabel);
		
		/*
		label = new JLabel[6];
		
		label[0] = new JLabel("추가");
		label[0].setBounds(70, 100, 150, 30);
		label[0].setBackground(Color.PINK);
		label[0].setOpaque(true);
		label[0].setHorizontalAlignment(JLabel.CENTER);
		label[0].setForeground(Color.white);
		add(label[0]);
		
		label[1] = new JLabel("삭제");
		label[1].setBounds(110, 150, 150, 30);
		label[1].setBackground(Color.green);
		label[1].setOpaque(true);
		label[1].setHorizontalAlignment(JLabel.CENTER);
		label[1].setForeground(Color.white);
		add(label[1]);
		
		label[2] = new JLabel("검색");
		label[2].setBounds(150, 200, 150, 30);
		label[2].setBackground(Color.ORANGE);
		label[2].setOpaque(true);
		label[2].setHorizontalAlignment(JLabel.CENTER);
		label[2].setForeground(Color.white);
		add(label[2]);
		
		label[3] = new JLabel("수정");
		label[3].setBounds(190, 250, 150, 30);
		label[3].setBackground(Color.RED);
		label[3].setOpaque(true);
		label[3].setHorizontalAlignment(JLabel.CENTER);
		label[3].setForeground(Color.white);
		add(label[3]);
		
		label[4] = new JLabel("출력");
		label[4].setBounds(230, 300, 150, 30);
		label[4].setBackground(Color.lightGray);
		label[4].setOpaque(true);
		label[4].setHorizontalAlignment(JLabel.CENTER);
		label[4].setForeground(Color.white);
		add(label[4]);
		
		label[5] = new JLabel("저장");
		label[5].setBounds(280, 350, 150, 30);
		label[5].setBackground(Color.magenta);
		label[5].setOpaque(true);
		label[5].setHorizontalAlignment(JLabel.CENTER);
		label[5].setForeground(Color.white);
		add(label[5]);
		*/
		button = new JButton[6];
		
		button[0]= new JButton("추가");
		button[0].setBounds(100, 100, 150, 30);
		button[0].setBackground(Color.LIGHT_GRAY);
		button[0].setOpaque(true);
		button[0].setHorizontalAlignment(JLabel.CENTER);
		button[0].setForeground(Color.black);
		button[0].addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Singleton sc =Singleton.getInstance();
				sc.ballOne.setVisible(false);
				sc.ballTwo.setVisible(true);
			}
		});
		add(button[0]);
		
		button[1]= new JButton("삭제");
		button[1].setBounds(320, 100, 150, 30);
		button[1].setBackground(Color.LIGHT_GRAY);
		button[1].setOpaque(true);
		button[1].setHorizontalAlignment(JLabel.CENTER);
		button[1].setForeground(Color.black);
		button[1].addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Singleton sc =Singleton.getInstance();
				sc.ballOne.setVisible(false);
				sc.ballTwo.setVisible(true);
			}
		});
		add(button[1]);
		
		button[2]= new JButton("검색");
		button[2].setBounds(100, 150, 150, 30);
		button[2].setBackground(Color.LIGHT_GRAY);
		button[2].setOpaque(true);
		button[2].setHorizontalAlignment(JLabel.CENTER);
		button[2].setForeground(Color.black);
		button[2].addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Singleton sc =Singleton.getInstance();
				sc.ballOne.setVisible(false);
				sc.ballTwo.setVisible(true);
			}
		});
		add(button[2]);
		
		button[3]= new JButton("수정");
		button[3].setBounds(320, 150, 150, 30);
		button[3].setBackground(Color.LIGHT_GRAY);
		button[3].setOpaque(true);
		button[3].setHorizontalAlignment(JLabel.CENTER);
		button[3].setForeground(Color.black);
		button[3].addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Singleton sc =Singleton.getInstance();
				sc.ballOne.setVisible(false);
				sc.ballTwo.setVisible(true);
			}
		});
		add(button[3]);
		
		button[4]= new JButton("출력");
		button[4].setBounds(100, 200, 150, 30);
		button[4].setBackground(Color.LIGHT_GRAY);
		button[4].setOpaque(true);
		button[4].setHorizontalAlignment(JLabel.CENTER);
		button[4].setForeground(Color.black);
		button[4].addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Singleton sc =Singleton.getInstance();
				sc.ballOne.setVisible(false);
				sc.ballTwo.setVisible(true);
			}
		});
		add(button[4]);
		
		button[5]= new JButton("저장");
		button[5].setBounds(320, 200, 150, 30);
		button[5].setBackground(Color.LIGHT_GRAY);
		button[5].setOpaque(true);
		button[5].setHorizontalAlignment(JLabel.CENTER);
		button[5].setForeground(Color.black);
		button[5].addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Singleton sc =Singleton.getInstance();
				sc.ballOne.setVisible(false);
				sc.ballTwo.setVisible(true);
			}
		});
		add(button[5]);
		
		
		
		
		
		setSize(640,480);
		setLocation(100, 0);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	
}
