package ex;

public class MainClass {

	public static void main(String[] args) {

		
			Singleton.getInstance().ballOne.setVisible(true);
	}

}
