package ex;

public class Singleton {

	
	
	private static Singleton sc = null;
	
	BaseballOne ballOne;
	BaseballTwo ballTwo;
	
	public Singleton() {
		ballOne = new BaseballOne();
		ballTwo = new BaseballTwo();
		
	}
	
	public static Singleton getInstance() {
		if(sc==null) {
			sc= new Singleton();
		}
		return sc;
	}
}
