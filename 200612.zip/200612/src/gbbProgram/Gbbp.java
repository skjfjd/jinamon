package gbbProgram;

public class Gbbp {

	
	private int userNum;
	private int comNum;
	private int win , lose, draw;
	private int result;
	
	
	public Gbbp() {
	
		win = lose = draw = 0;
	}
	
	
	public void init() {
		comNum = ((int)Math.random()*3);
		
	}
	public String play() {
		String msg="";
		
	/*	//win
		if(userNum == 0 && comNum ==2) {
			
		}else if (userNum==1 && comNum == 0){
		
		}else if (userNum == 2 && comNum ==1) {
			
		}
		// lose
		if(userNum == 2 && comNum ==0) {}
		else if (userNum == 0 && comNum ==1) {}
		else if (userNum==1 && comNum==2) {}
		// draw
		if(userNum==0 && comNum ==0) {}
		else if(userNum==1 && comNum ==1) {}
		else if(userNum==2 && comNum==2) {}
		*/
		
		result = (comNum - userNum +2) % 3 ;
		
		switch(result) {
		case 1:
			win++;
			msg= "승리!";
			break;
			
		case 0 :
			lose++;
			msg = "아쉽..";
			break;
		case 2:
			draw++;
			msg= "무승부";
			break;
		}
		return msg;
		
		
			
		
		
	}


	public int getWin() {
		return win;
	}


	public int getLose() {
		return lose;
	}


	public int getDraw() {
		return draw;
	}


	public void setUserNum(int userNum) {
		this.userNum = userNum;
	}
		
	public String getuser() {
		String userChoice ="";
		
		switch(userNum) {
		case 0:
			userChoice = "가위";
			break;
		case 1:
			userChoice = "바위";
			break;
		case 2:
			userChoice = "보";
			break;
		}
		return userChoice;
	}
	public String getCom() {
		String comChoice ="";
		
		switch(comNum) {
		case 0:
			comChoice = "가위";
			break;
		case 1:
			comChoice = "바위";
			break;
		case 2:
			comChoice = "보";
			break;
		}
		return comChoice;
	}
		
		
		
		


}

