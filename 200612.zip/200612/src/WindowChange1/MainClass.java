package WindowChange1;

public class MainClass {

	public static void main(String[] args) {

		/*
		 	window(Frame) > 	Frame
		 	
		 	
		 	1. close	  		new
		 	
		 	2.setVisible(true) false
		 		false			true
		 
		 	3.Panel
		 	  Panel1			Panel2
		 		 
		 */
		
		new WindowOne();
		
		
	}

}
