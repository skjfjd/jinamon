package WindowChange1;

import java.awt.Button;
import java.awt.Color;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import WindowChange2.SingletonClass;

public class WindowOne extends Frame {

	
	public WindowOne() {
		
		setLayout(null);
		
		Button btn = new Button("move window");
		btn.setBounds(100, 100, 100, 30);
		btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				//System.exit(0);
				SingletonClass sc = SingletonClass.getInstance();
				
				
				
			}
		});
		add(btn);
		
		setBounds(0, 0, 640, 480);
		setVisible(true);
		setBackground(Color.red);
		
		
		
	}
}
