package WindowChange1;

import java.awt.Frame;

public class WindowTwo extends Frame{

	
	public WindowTwo() {
		
		setBounds(0, 0, 800, 600);
		setVisible(true);
		
	}
}
