package awt8;

public class MainClass   {

	public static void main(String[] args) {

		
		new WindowTest();
		
	}

}
