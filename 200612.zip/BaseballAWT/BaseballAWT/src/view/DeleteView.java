package view;

import javax.swing.JFrame;

public class DeleteView extends JFrame {

}
