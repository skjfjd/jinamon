package bj;

public class Rule {

}
