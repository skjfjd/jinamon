package main;

import db.DBConnection;
import view.LoginView;
import view.Singleton;

public class MainClass {

	public static void main(String[] args) {
		DBConnection.initConnection();
		new LoginView();
	}

}
