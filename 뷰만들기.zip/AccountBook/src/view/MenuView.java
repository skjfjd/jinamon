package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class MenuView extends JFrame implements ActionListener{

	

	private JButton addBtn;
	private JButton monthBtn;
	private JButton itemBtn;
	
	public  MenuView() {
		super("메뉴 화면");
		setLayout(null);
		
		JLabel menuLabel = new JLabel("메뉴");
		menuLabel.setBounds(180, 10, 100, 50);
		menuLabel.setFont(menuLabel.getFont().deriveFont(18.0f));
		add(menuLabel);
		
		addBtn = new JButton("추가");
		addBtn.setBounds(120, 70, 150, 50);
		addBtn.addActionListener(this);
				add(addBtn);
		
		monthBtn = new JButton("기간별 내역");
		monthBtn.setBounds(120, 150, 150, 50);
		monthBtn.addActionListener(this);
		add(monthBtn);
		
		itemBtn = new JButton("항목별 검색");
		itemBtn.setBounds(120, 230, 150, 50);
		itemBtn.addActionListener(this);
		add(itemBtn);
		
		
		
		setBounds(180,300,400,380);
		setVisible(true);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		

	}
	
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		JButton btn =(JButton)e.getSource();
		if(btn== addBtn){
			new AddView();
			this.dispose();
		}else if(btn==monthBtn) {
			new MonthView();
			this.dispose();
		}
	}
}
