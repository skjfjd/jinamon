package view;

public class Singleton {

	
	private static Singleton  sc = null;
	
	
	public LoginView one;
	public AccountView two;
	
	private Singleton() {
		one = new LoginView();
		two = new AccountView();
	}
	
	public static Singleton getInstance() {
		if(sc==null) {
			sc = new Singleton();
		}
		return sc;
	}
	
	
	
	
}
