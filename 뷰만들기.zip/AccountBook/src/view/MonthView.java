package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class MonthView extends JFrame implements ActionListener {
	
	private JComboBox year =new JComboBox();
	private JComboBox month =new JComboBox();
	private JComboBox day =new JComboBox();
	
	private JLabel y = new JLabel("년도");
	private JLabel m = new JLabel("월");
	private JLabel d = new JLabel("일");
	
	Calendar cr = Calendar.getInstance();
	
	int nowYear = cr.get(Calendar.YEAR);
	int nowMonth = cr.get(Calendar.MONTH);
	int nowDay = cr.get(Calendar.DAY_OF_MONTH);

	
	
	
	  public MonthView() {
		  super("기간별 내역 출력");
			  setLayout(null);
		
			  y= new JLabel();
			for(int i = 1900; i<=2019; i++) {
				
				year.addItem(i);
			}
			
			year.setBounds(15, 10, 70, 30);
			add(y);
			add(year);
			
			
			for(int j=1;j<13;j++) {
				month.addItem(j);
			}
			add(month);
			add(m);
			
			for(int k =1; k<=31; k++) {
				day.addItem(k);
			}
			add(day);
			add(d);
			  
			  
		  
	
			  
			  
		  
		  
		    setBounds(180,300,500,480);
			setVisible(true);
			
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		  }
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
