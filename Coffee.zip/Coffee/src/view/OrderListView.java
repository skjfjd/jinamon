package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class OrderListView extends JFrame implements ActionListener {
String[] strMenu = {"주문한 음료" , "시럽" , "크기" , "샷 추가" , "휘핑 크림" , "잔" , "총액"};
	
	JLabel[] stLabel;


	public OrderListView() {
		setLayout(null);
		
		JLabel orderList = new JLabel("주문내역");
		orderList.setBounds(350, 100, 100, 20);
		orderList.setFont(orderList.getFont().deriveFont(18.0f));
		add(orderList);
		
		 stLabel = new JLabel[strMenu.length];
		 for (int i = 0; i < stLabel.length; i++) {
			stLabel[i] = new JLabel(strMenu[i]);
			stLabel[i].setBounds(70+100*i, 140, 100, 30);
			
			add(stLabel[i]);
		}
		 
		setBounds(100, 200, 800, 700);
		setLocation(500,100);
		setVisible(true);
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
