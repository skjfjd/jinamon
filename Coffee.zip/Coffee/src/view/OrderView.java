package view;

import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

import dao.MemberDao;
import dto.MenuDto;

public class OrderView extends JFrame implements ActionListener {
	private JPanel choicePanel; 
	private JPanel sizePanel; 
	private JPanel syrupPanel; 
	private JPanel ShotPanel; 
	Choice menuChoice;
	private JTextField choiceF ,sizeF ,janF;
	
	private JButton priceList;
	private JButton orderBtn;
	
	private JCheckBox shotCheckBtn , wheepingCheckBtn;
	
	private ButtonGroup sizeGroup , syrupGroup;
	
	JRadioButton shortButton , tallButton , grandeButton , banilaRButton ,caramelRButton , hazelnutsRButton;
	public OrderView() {
		super("커피 주문 프로그램");
		setLayout(null);
		//setLayout(null);
		
		
		
		JLabel pLabel = new JLabel("Coffee Prince Song ~");
		pLabel.setBounds(40, 20, 400, 100);
		pLabel.setFont(new Font("Serif", Font.BOLD, 40));
		add(pLabel);
		
		priceList = new JButton("가격표 보기");
		priceList.setBounds(600, 60, 150, 40);
		priceList.setBackground(new Color(0,191,255));
		priceList.addActionListener(this);
		add(priceList);
		
		/*choiceF = new JTextField("Choice(커피 선택)");
		choiceF.setBounds(170, 180, 500, 30);
		choiceF.setFont(new Font("Serif", Font.BOLD, 20));
		choiceF.addActionListener(this);
		add(choiceF);*/
		
		//사이즈
		sizePanel = new JPanel();
		sizePanel.setLayout(new GridLayout(5,1));
		sizePanel.setBorder(new LineBorder(Color.black,1));
		
		sizePanel.setBounds(100, 300, 180, 180);
		
		JLabel sizeF = new JLabel("크기");
		sizeF.setFont(sizeF.getFont().deriveFont(25.0f));
		sizeGroup = new ButtonGroup();
		
		shortButton = new JRadioButton("Short");
		tallButton = new JRadioButton("Tall");
		grandeButton= new JRadioButton("Grande");
		
		sizePanel.add(sizeF);
		
		sizeGroup.add(shortButton);
		sizeGroup.add(tallButton);
		sizeGroup.add(grandeButton);
		
		sizePanel.add(shortButton);
		sizePanel.add(tallButton);
		sizePanel.add(grandeButton);
		
		add(sizePanel);
		
		//시럽
		
		syrupPanel =new JPanel();
		syrupPanel.setLayout(new GridLayout(5,1,10,10));
		syrupPanel.setBorder(new LineBorder(Color.black,1));
		
		syrupPanel.setBounds(300, 300, 180, 180);
		
		JLabel syrupLabel = new JLabel("시럽");
		syrupLabel.setFont(syrupLabel.getFont().deriveFont(25.0f));
		
		syrupGroup = new ButtonGroup();
		
		banilaRButton =new JRadioButton("바닐라");
		caramelRButton = new JRadioButton("카라멜");
		hazelnutsRButton =new JRadioButton("헤이즐넛");
		
		syrupPanel.add(syrupLabel);
		syrupGroup.add(banilaRButton);
		syrupGroup.add(caramelRButton);
		syrupGroup.add(hazelnutsRButton);
		
		syrupPanel.add(banilaRButton);
		syrupPanel.add(caramelRButton);
		syrupPanel.add(hazelnutsRButton);
		
		add(syrupPanel);
		
		ShotPanel = new JPanel();
		ShotPanel.setLayout(new GridLayout(5,1,10,10));
		ShotPanel.setBorder(new LineBorder(Color.black,1));
		
		ShotPanel.setBounds(500, 300, 180, 180);
		
		JLabel etcLabel = new JLabel("기타");
		
		shotCheckBtn = new JCheckBox("샷 추가");
		wheepingCheckBtn = new JCheckBox("휘핑 크림");
		
		ShotPanel.add(etcLabel);
		ShotPanel.add(shotCheckBtn);
		ShotPanel.add(wheepingCheckBtn);
		
		
		
		add(ShotPanel);
		
				
		
		
		janF = new JTextField();
		janF.setBounds(200,600 ,100,40);
		add(janF);
		
		JLabel janLabel = new JLabel("잔");
		janLabel.setBounds(350, 600, 100, 40);
		janLabel.setFont(new Font("Serif", Font.BOLD ,20));
		add(janLabel);
		
		orderBtn = new JButton("주문");
		orderBtn.setBounds(500, 600, 100, 40);
		orderBtn.setFont(new Font("Serif", Font.BOLD,20));
		orderBtn.setBackground(new Color(0,191,255));
		orderBtn.addActionListener(this);
		
		add(orderBtn);
		
		menuChoice =new Choice();
		menuChoice.add("에스프레소");
		menuChoice.add("헤이즐넛 카라멜 모카");
		menuChoice.add("카라멜 마끼아또");
		menuChoice.add("화이트 초콜릿 모카");
		menuChoice.add("카라멜 모카");
		menuChoice.add("카페 모카");
		menuChoice.add("카라멜 라떼");
		menuChoice.add("카푸치노");
		menuChoice.add("아메리카노");
		menuChoice.add("오늘의 커피");
		
		List<MenuDto> list =new ArrayList<>(); 
		
		for (int i = 0; i < list.size(); i++) {
			menuChoice.add(list.get(i).getMenu());
		}
		menuChoice.setBounds(150, 200, 500, 40);
		
		add(menuChoice);
		setBounds(400, 100, 900, 800);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
	}

	boolean b = true;

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton btn = (JButton)e.getSource();
		String btnTitle = btn.getLabel();
		if(btn==priceList) {
			new MenuView();
			
			
		}else if(btnTitle.equals("주문")) {
			MemberDao dao = MemberDao.getInstance();
		
			
			String jan = janF.getText().trim();
			boolean b = dao.getId(jan);
		}
	}

}