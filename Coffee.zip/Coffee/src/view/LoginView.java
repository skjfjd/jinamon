package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.text.StyledEditorKit.ItalicAction;

import dao.MemberDao;
import dto.MemberDto;

public class LoginView extends JFrame implements ActionListener {
	
	private JTextField idTextF;
	private JTextField pwTextF;
	
	private JButton logBtn;
	private JButton accountBtn;
	
	
	
	public  LoginView() {
		super("로그인 화면");
			setLayout(null);
		JLabel upLabel = new JLabel(" Coffee Prince Song ~");
		upLabel.setBounds(20, 20, 220, 100);
		upLabel.setFont(upLabel.getFont().deriveFont(20.0f));
		upLabel.setFont(new Font("Serif", Font.BOLD, 20));
		add(upLabel);
			
		
		idTextF = new JTextField();
		idTextF.setBounds(100, 120, 240, 30);
		add(idTextF);
		
		JLabel idLabel = new JLabel("ID : ");
		idLabel.setBounds(65, 120, 30, 30);
		add(idLabel);
		
		pwTextF = new JTextField();
		pwTextF.setBounds(100, 170, 240, 30);
		add(pwTextF);
		
		JLabel pwLabel = new JLabel("Password:");
		pwLabel.setBounds(20, 170, 70, 30);
		add(pwLabel);
		
		logBtn = new JButton("로그인");
		logBtn.setBounds(65, 250, 130, 40);
		logBtn.setBackground(new Color(0,191,255));
		logBtn.addActionListener(this);
		add(logBtn);
		
		accountBtn = new JButton("회원가입");
		accountBtn.setBounds(210, 250, 130, 40);
		accountBtn.addActionListener(this);
		accountBtn.setBackground(new Color(0,191,255));
		add(accountBtn);

		
		
		setBounds(100, 100, 450, 400);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		
	}	
	
	
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		JButton btn = (JButton)e.getSource();
		
		MemberDao dao = MemberDao.getInstance();
		if(btn == logBtn) {
			MemberDto mem = dao.login(idTextF.getText() , pwTextF.getText());
		if(mem == null) {
			JOptionPane.showMessageDialog(null, "iD 나 패스워드가 맞지 않습니다");
		}else {
			JOptionPane.showMessageDialog(null, mem.getId() + "님 환영합니다");
			this.dispose();
			
			
			//로그인한 아이디 저장하는 공간
			dao.setLoginID(mem.getId());
			
			new OrderView();
			
		}
		}
		else if(btn== accountBtn) {
			new AccountView();
			this.dispose();
		}
	}

}
