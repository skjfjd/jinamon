
package dto;

public class MenuDto {
	
	private int seq;
	private String menu;
	private int shortSize;
	private int tallSize;
	private int grandeSize;
	
	public MenuDto() {
		
	}

	public MenuDto(int seq, String menu, int shortSize, int tallSize, int grandeSize) {
		super();
		this.seq = seq;
		this.menu = menu;
		this.shortSize = shortSize;
		this.tallSize = tallSize;
		this.grandeSize = grandeSize;
	}

	public int getSeq() {
		return seq;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public String getMenu() {
		return menu;
	}

	public void setMenu(String menu) {
		this.menu = menu;
	}

	public int getShortSize() {
		return shortSize;
	}

	public void setShortSize(int shortSize) {
		this.shortSize = shortSize;
	}

	public int getTallSize() {
		return tallSize;
	}

	public void setTallSize(int tallSize) {
		this.tallSize = tallSize;
	}

	public int getGrandeSize() {
		return grandeSize;
	}

	public void setGrandeSize(int grandeSize) {
		this.grandeSize = grandeSize;
	}

	@Override
	public String toString() {
		return "MenuDto [seq=" + seq + ", menu=" + menu + ", shortSize=" + shortSize + ", tallSize=" + tallSize
				+ ", grandeSize=" + grandeSize + "]";
	}
	
	
	
	
	
	
	
}
