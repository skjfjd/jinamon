package main;

import db.DBConnection;
import view.LoginView;

public class Main {

	public static void main(String[] args) {
		
		DBConnection.initConnection();
		new LoginView();
	}

}
