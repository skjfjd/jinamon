package view;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import dto.MemberDto;
import singleton.Singleton;

public class loginView extends JFrame implements ActionListener {

	private JTextField idTextF;
	private JPasswordField pwTextF;
	
	private JButton logBtn;
	private JButton accountBtn;
	
	public loginView() {
		super("로그인"); // ui 로고
		setLayout(null);
		
		JLabel loginLabel = new JLabel("로그인 화면"); //상단 로고
		loginLabel.setBounds(100, 10, 120, 15); //로그인 화면 위치와 크기 배치
		add(loginLabel); // 로그인 화면 생성
		
		JLabel idLabel = new JLabel("ID:"); // id 라벨
		idLabel.setBounds(31, 60, 67, 15); // id 위치와 크기 생성
		add(idLabel); // id 라벨 생성
		
		idTextF = new JTextField(10);  // id  글씨 옆에 네모난 텍스트 창
		idTextF.setBounds(100, 60, 150, 20); // 네모난 창 위치와 크기 배치
		add(idTextF); // 네모난 텍스트창 생성
		
		JLabel passLabel = new JLabel("PW:"); // pw 라벨
		passLabel.setBounds(31, 104, 67, 15); // pw  위치와 크기 생성
		add(passLabel); // pw 라벨 생성
		
		pwTextF = new JPasswordField(); // pw 옆 텍스트 네모난창
		pwTextF.setBounds(100, 104, 150, 20); // pw 네모난창 위치와 크기 배치
		add(pwTextF); // pw 네모난 창 생성
				
		logBtn = new JButton("log-in"); //  login 버튼
		logBtn.setBounds(31, 150, 100, 40); // 로그인 버튼 위치와 크기 배치
		logBtn.addActionListener(this); // 버튼을 눌렀을때  이벤트가 발생시켜줌
		add(logBtn); // 로그인 버튼 생성
		
		accountBtn = new JButton("회원가입"); // 회원가입 버튼
		accountBtn.setBounds(150, 150, 100, 40); // 회원가입 버튼 위치와 크기 배치
		accountBtn.addActionListener(this); // 버튼을 눌렀을때 이벤트 발생
		add(accountBtn); // 회원가입 버튼 생성
		
		setBounds(100, 100, 300, 280);  // 화면 창 크기
		getContentPane().setBackground(Color.yellow); // 화면 배경 설정
		setVisible(true); // 실행창 켜지게 (true) 값 설정
		
		this.addWindowListener(new WindowAdapter() {  //addWindowListener  을 이용해 창을 만들고  WindowAdapter 을 사용하여 창을 닫는것을 도와준는 역할
			@Override
			public void windowClosing(WindowEvent e) {	//윈도우창 닫기	 		
				System.exit(0);				//exit 를 이용하여 시스템 종료
			}			
		});
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {		
		JButton btn = (JButton)e.getSource();  // jbutton  btn 변수를 만들어 actionevent 의 e 를 이용하여 getsource를 가져온다

		Singleton s = Singleton.getInstance();
		
		if(btn == logBtn){	// log in
			// controller로 이동
			s.memCtrl.loginAf(idTextF.getText(), pwTextF.getText());
			dispose();
		} else if (btn == accountBtn) { //회원가입
			s.memCtrl.regi();
			this.dispose();
		}
	}

}






















