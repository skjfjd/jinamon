"# JAVA_COFEE_ORDER" 

화면에 대한 설명 블로그 https://loy124.tistory.com/128

![image](https://user-images.githubusercontent.com/35419326/71608245-27870a80-2bc3-11ea-9e77-18e20799827e.png)
