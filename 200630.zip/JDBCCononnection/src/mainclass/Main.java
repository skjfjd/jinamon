package mainclass;

import jdbc.JdbcConnect;

public class Main {
	
	public static void main(String[] args) {
		
		JdbcConnect jc = new JdbcConnect();
		
		jc.getConnection();
	}
}
