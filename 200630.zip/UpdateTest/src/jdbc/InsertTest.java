package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class InsertTest {

	
	public InsertTest() {
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver"); // 클래스의 이름을 만듬  예외 만듬 파일이 없다 예외 뜸
			System.out.println("Driver Loading Success");
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}	
		}
		
		public Connection getConnection() {
			Connection conn= null;
			try {
				conn = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:xe" , "scott" ,"tiger");
				
				System.out.println("Oracle Connection Success!");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
					
			return conn;
}
		public int insertData(String id, String name , int age) {
			//Query -> String
			String sql = " INSERT INTO USERTEST(ID ,NAME ,AGE, JOINDATE) "
					+ " VALUES('" + id + "','" + name + "', " + age + ", SYSDATE)";
			System.out.println("sql : " + sql);
			
			Connection conn = this.getConnection();
			Statement stat = null;
			
			int count = 0;  //몇개가 변경되었는지?  리턴 제물
			
			try {
				stat = conn.createStatement();
				
			count=stat.executeUpdate(sql);
				System.out.println("성공적으로 추가 되었습니다.");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
						
					 try {
						if(stat != null) {
						stat.close();
				}if(conn != null) {
					conn.close();
				}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
			}
			return count;
		}
		
		
		
		
		
		
}