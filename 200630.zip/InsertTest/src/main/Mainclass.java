package main;

import jdbc.InsertTest;

public class Mainclass {

		public static void main(String[] args) {
			
			InsertTest it =new InsertTest();
			
			int count = it.insertData("abc", "홍길동", 24);
			if(count == 1) {
				System.out.println("데이터가" + count + "개 추가 되었습니다");
			}
		}
}
