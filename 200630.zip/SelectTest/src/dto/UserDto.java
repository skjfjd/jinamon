package dto;

import java.io.Serializable;

public class UserDto implements Serializable {
		
	private String id;
	private String name;
	private int age;
	private String joinDate;
	
	public UserDto(String _id, String _name, int _age, String _joinDate) {
		
	}

	public UserDto() {
		// TODO Auto-generated constructor stub
	}

	public void setId(String string) {
		// TODO Auto-generated method stub
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getJoinDate() {
		return joinDate;
	}

	public void setJoinDate(String joinDate) {
		this.joinDate = joinDate;
	}

	public String getId() {
		return id;
	}
	
	
	
	
	
	
	
	
	
	
}
