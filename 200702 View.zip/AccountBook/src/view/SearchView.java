package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class SearchView extends JFrame implements ActionListener {
	private JButton returnBtn;
	private JButton searchBtn;
	private JTextField searchF;
	private JTextField resultF;
	
	public SearchView() {
		super("항목별 검색");
		setLayout(null);
		
		resultF = new JTextField();
		resultF.setBounds(60, 80, 350, 250);
		add(resultF);
		
		searchF = new JTextField();
		searchF.setBounds(60, 30, 250, 30);
		add(searchF);
		
		searchBtn = new JButton("결과");
		searchBtn.setBounds(330, 30, 80, 30);
		searchBtn.addActionListener(this);
		add(searchBtn);
		
		
		returnBtn = new JButton("메뉴로 돌아가기");
		returnBtn.setBounds(60, 350, 350, 50);
		returnBtn.addActionListener(this);
		add(returnBtn);
		
		
		
		
		 setBounds(180,300,500,480);
			setVisible(true);
			
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	
	
	
	
	
	
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
			JButton Btn =(JButton)arg0.getSource();
			if(Btn==returnBtn) {
				new MenuView();
				this.dispose();
			}
	}

}
