package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class AddView extends JFrame implements ActionListener{

		private JTextField moneyTextF;
		private JTextField contentsTextF;
	
		private JButton addBtn;
		private JButton returnBtn;
	public AddView() {
		super("가계부");
		setLayout(null);
		ButtonGroup  group= new ButtonGroup();
		
		JRadioButton rb1= new JRadioButton("수입");
		rb1.setBounds(50, 20, 100, 30);
		add(rb1);
		
		
		
		JRadioButton rb2= new JRadioButton("지출");
		rb2.setBounds(150, 20, 100, 30);
		add(rb2);
		
		
		group.add(rb1);
		group.add(rb2);
		
		JLabel moneyLabel = new JLabel("금액:");
		moneyLabel.setBounds(25,65,100,100);
		moneyLabel.setFont(moneyLabel.getFont().deriveFont(18.0f));
		add(moneyLabel);
		
		JLabel contentsLabel = new JLabel("내용:");
		contentsLabel.setBounds(25,115,100,100);
		contentsLabel.setFont(contentsLabel.getFont().deriveFont(18.0f));
		add(contentsLabel);
		
		
		moneyTextF = new JTextField();
		moneyTextF.setBounds(100, 100, 200, 30);
		add(moneyTextF);
		
		contentsTextF = new JTextField();
		contentsTextF.setBounds(100, 150, 200, 30);
		add(contentsTextF);
		
		addBtn = new JButton("추가");
		addBtn.setBounds(120, 200, 150, 40);
		add(addBtn);
		
		returnBtn = new JButton("메뉴로 돌아가기");
		returnBtn.setBounds(50, 280, 280, 30);
		returnBtn.addActionListener(this);
		add(returnBtn);
		
		setBounds(300,300,400,400);
		setVisible(true);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}
	
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		JButton btn = (JButton)e.getSource();
		if(btn == returnBtn) {
			new MenuView();
			this.dispose();
		}
		
	}

	
}
