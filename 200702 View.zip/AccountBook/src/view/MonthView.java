package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class MonthView extends JFrame implements ActionListener {
	
	private JComboBox year =new JComboBox();
	private JComboBox year1 =new JComboBox();
	private JComboBox month =new JComboBox();
	private JComboBox month1 =new JComboBox();
	private JComboBox day =new JComboBox();
	private JComboBox day1 =new JComboBox();
	private JLabel y = new JLabel("년도");
	private JLabel m = new JLabel("월");
	private JLabel d = new JLabel("일");
	private JButton rBtn;
	private JButton returnBtn;
	
	private JTextField result;
	Calendar cr = Calendar.getInstance();
	
	int nowYear = cr.get(Calendar.YEAR);
	int nowMonth = cr.get(Calendar.MONTH);
	int nowDay = cr.get(Calendar.DAY_OF_MONTH);

	
	
	
	  public MonthView() {
		  super("기간별 내역 출력");
			  setLayout(null);
		
			  
			for(int i = 1900; i<=2019; i++) {
				
				year.addItem(i);
			
			
				
			}
							
			year.setBounds(30, 30, 70, 30);
			
			add(y);
			add(year);
			
			
			for(int j=1;j<13;j++) {
				month.addItem(j);
			}
			month.setBounds(150, 30, 70, 30);
			add(month);
			add(m);
			
			for(int k =1; k<=31; k++) {
				day.addItem(k);
			}
			day.setBounds(270, 30, 70, 30);
			add(day);
			add(d);
			  
			 JLabel cloud = new JLabel("~");
			 cloud.setBounds(390, 30, 70, 30);
			 cloud.setFont(cloud.getFont().deriveFont(18.0f));
			 add(cloud);
	
			 for(int i = 1900; i<=2019; i++) {
					
					year1.addItem(i);
				
				
					
				}
								
				year1.setBounds(50, 90, 70, 30);
				
				add(y);
				add(year1);
				  

				for(int j=1;j<13;j++) {
					month1.addItem(j);
				}
				month1.setBounds(180, 90, 70, 30);
				add(month1);
				add(m);
				
				for(int k =1; k<=31; k++) {
					day1.addItem(k);
				}
				day1.setBounds(310, 90, 70, 30);
				add(day1);
				add(d);
		  
				rBtn = new JButton("결 과 보 기");
				rBtn.setBounds(80, 150, 330, 60);
				rBtn.setFont(rBtn.getFont().deriveFont(20.0f));
				add(rBtn);
				
				returnBtn = new JButton("메뉴로 돌아가기");
				returnBtn.setBounds(60, 350, 350, 50);
				returnBtn.addActionListener(this);
				add(returnBtn);
				
				result = new JTextField();
				result.setBounds(40, 220, 400, 120);
				add(result);
		    setBounds(180,300,500,480);
			setVisible(true);
			
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		  }
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		JButton Btn = (JButton)e.getSource();
			if(Btn==returnBtn) {
				new MenuView();
				this.dispose();
			}
	}

}
