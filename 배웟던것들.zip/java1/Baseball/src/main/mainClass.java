package main;

import java.util.Scanner;

public class mainClass {

	public static void main(String[] args) {
		/*
			Baseball
			random number -> 3��		r1 != r2 != r3
			user number -> 3��
	
			��
			�޽��� ��� ?Strike ?Ball
			
			play again
		*/
		
		Scanner sc = new Scanner(System.in);
		
		int r_num[] = new int[3];
		int u_num[] = new int[3];	// 10�� (1 ~ 10) - 00000 00000 -> 01000 00000
		boolean clear;
		
		boolean swit[] = new boolean[10];
				
		for (int i = 0; i < swit.length; i++) {
			swit[i] = false;	// 00000 00000
		}
		clear = false;
		
		int r, w;		
		w = 0; 
				
		while(w < 3) {
			r = (int)(Math.random() * 10);	// 0 ~ 9
			if(swit[r] == false) {
				swit[r] = true;		// 00100 00000
				r_num[w] = r + 1;			// 1 ~ 10
				w++;
			}
		}
		
		for (int i = 0; i < r_num.length; i++) {
			System.out.println(i + " : " + r_num[i]);
		}
		
		// Debug != ����   
		// �ǽð�
		// break pointer
		
		/*
		while(true) {
			
			//r_num[0] = (int)(Math.random() * 10) + 1; 
			//r_num[1] = (int)(Math.random() * 10) + 1; 
			//r_num[2] = (int)(Math.random() * 10) + 1; 
			
			for (int i = 0; i < r_num.length; i++) {
				r_num[i] = (int)(Math.random() * 10) + 1; 
			}
			
			if(r_num[0] != r_num[1] 
					&& r_num[0] != r_num[2]
							&& r_num[1] != r_num[2]) {
				break;
			}
		}
		*/		
				
		/////////////////// loop 10
		w = 0;
		int strike, ball;
		while(w < 10) {
			
			// user input  u1 != u2 != u3
			boolean check;
			int w1;
			while(true) {
				check = false;
				w1 = 0;
				while(w1 < 3) {
					System.out.print((w1 + 1) + "��° �� = ");
					u_num[w1] = sc.nextInt();
					w1++;
				}
				
				// ���� ���ڰ� �ִ��� ýũ
				out:for (int i = 0; i < u_num.length; i++) {
					for (int j = 0; j < u_num.length; j++) {
						if(u_num[i] == u_num[j] && i != j) {
							check = true;	// �Է��� ���� ���ڰ� ���� 
							break out; 
						}
					}
				}
				
				if(check == false) {
					break;
				}				
				System.out.println("�Է��� ���� �߿� �ߺ��Ǵ� ���ڰ� �ֽ��ϴ�. �ٽ� �Է��� �ֽʽÿ�");
			}			
			
			// process(��)
			strike = ball = 0;
			// ball
			for (int i = 0; i < u_num.length; i++) {
				for (int j = 0; j < r_num.length; j++) {
					if(u_num[i] == r_num[j] && i != j) {
						ball++;
					}					
				}
			}
			// strike
			for (int i = 0; i < u_num.length; i++) {
				if(u_num[i] == r_num[i]) {
					strike++;
				}
			}
			// Ż��
			if(strike > 2) {
				clear = true;
				break;						
			}
			
			// �޽��� ���
			System.out.println(strike + "��Ʈ����ũ, " + ball + "�� �Դϴ�");
						
			w++;
		}	
		
		if(clear) {
			System.out.println("Game Clear!!");
		}else {
			System.out.println("Game Over~ ");
		}

	}

}








