
public class Study {
	
public static void main(String[]args) {
	System.out.println("====================================================");
	System.out.println("|     �̸�               ����                 ��ȭ��ȣ                  �ּ�          |");
	System.out.print("====================================================\n");
	System.out.print("|    ȫ�浿             20        010-111-2222    ��⵵         |\n");
	System.out.print("|    ������             18        02-123-4567      ����          |\n");
	System.out.println("====================================================");
	
	
	

	
	
	
	
	
}
}
