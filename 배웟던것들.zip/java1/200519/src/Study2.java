
public class Study2 {
	public static void main(String[] args) {
		
		System.out.print("=========================================================\n");
		System.out.print("\\ name\t\tage\t\tphone\t\taddress\t\\\n");
		System.out.print("=========================================================\n");
		System.out.print("\\ \"ȫ�浿\" \t20\t\t010-111-2222\t\'��⵵\'\t\\\n");
		System.out.print("\\ \"������\" \t18\t\t02-345-4567\t\'����\'\t\\\n");
		System.out.print("=========================================================\n");
	}
	
}
