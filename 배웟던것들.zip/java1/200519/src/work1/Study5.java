package work1;

public class Study5 {
	public static void main(String[ ]args) {
		
		
		int a;
		int b;
		
		
		a = 100;
		b = 200;
		
		if(a>b) {
			System.out.println(">");
		}else {
			System.out.println("<");
		}
	}
}
