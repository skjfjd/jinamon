package work1;

import java.util.Scanner;

public class Work1 {
	public static void main(String[] args) {
		String name;
		int age;
		boolean lady;
		String phone;
		double height;
		String address;
		
		System.out.println("=================================================================================");
		System.out.println("\\\tname\tage\tlady\t\tphone\t\theight\t\taddress\t\\");
		System.out.println("=================================================================================");
		
		name = "ȫ�浿";
		age = 24;
		lady = false;
		phone ="010-111-2222";
		height =175.12;
		address = "��⵵";
	
		System.out.print("\\\t"+ name + "\t"+ age + "\t" + lady + "\t\t" + phone + "\t"+ height + "\t\t" + address + "\t\\\n");
		
		name = "������";
		age = 18;
		lady = false;
		phone ="02-123-4567";
		height =180.01;
		address = "����";
		
		System.out.print("\\\t"+ name + "\t"+ age + "\t" + lady + "\t\t" + phone + "\t"+ height + "\t\t" + address + "\t\\\n");
		
		name = "�����";
		age = 14;
		lady = true;
		phone ="02-345-7890";
		height =155.78;
		address = "�λ�";
		System.out.print("\\\t"+ name + "\t"+ age + "\t" + lady + "\t\t" + phone + "\t"+ height + "\t\t" + address + "\t\\\n");
		System.out.println("=================================================================================");
		
		
		
		
		// �Է� class
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("�̸�:");
		name = scan.next();
		
		System.out.print("����:");
		age = scan.nextInt();
		
		System.out.print("Ű:");
		height = scan.nextDouble();
		
		
		
		
		//swap == ��ȯ
		
		
		int x,y;
		int a , b ;
		x=111;
		y=222;
		
		
		
		a= x;
		b= y;
		
		
		
		x = b;
		y = a;
		
		System.out.println("x=" +x +"y="+ y );
		
		int x1 , y1;
		int temp;
		
		x1 =333;
		y1= 222;
		
		temp= x1;
		x1 = y1;
		y1= temp;
		System.out.println("x1=" + x1 + "y1=" + y1);
	
		
		
		
	}
}
