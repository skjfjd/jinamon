import java.util.Scanner;

public class Study3 {
	
		private static boolean String;

		public static void main(String[] args) {
			String name;
			int age;
			boolean lady;
			String phone;
			double height;
			String address;
			
			
			System.out.println("================================================================================");
			System.out.println("\\\tname\tage\tlady\t\tphone\t\theight\t\taddress\\");
			System.out.println("================================================================================");
			
			name = "ȫ�浿";
			age = 20;
			lady = false;
			phone = "010-111-2222";
			height = 175.01;
			address = "��⵵";
			
	System.out.println("\\\t\"" + name +"\"" +"\t" + age +"\t" + lady + "\t\t" + phone +"\t"+ height +"\t\t\"" + address+"\"" +"\t\\");
			
	name = "������";
	age = 18;
	lady = false;
	phone = "02-1234-5678";
	height = 180.05;
	address = "����";
	System.out.println("\\\t\"" + name +"\"" +"\t" + age +"\t" + lady + "\t\t" + phone +"\t"+ height +"\t\t\"" + address+"\"" +"\t\\");
	
		name = "�����";
		age = 14;
		lady = true;
		phone = "010-4567-8901";
		height = 155.75;
		address = "�λ�";
	System.out.println("\\\t\"" + name +"\"" +"\t" + age +"\t" + lady + "\t\t" + phone +"\t"+ height +"\t\t\"" + address+"\"" +"\t\\");
	
	
	
	// �Է� class
	
		/*	Scanner scan = new Scanner(System.in);
			
			System.out.print("�̸�:");
			name = scan.next();
			
			System.out.print("����:");
			age = scan.nextInt();
			
			System.out.print("����:");
			lady = scan.hasNextBoolean();
			
			System.out.println("��ȭ��ȣ:");
			phone = scan.next();
			
			System.out.print("Ű:");
			height = scan.nextDouble();
			
			System.out.print("�ּ�:");
			address = scan.next();*/
			
			
			
			// swap
			
			
			int x,y;
			
			int temp;
			
			x = 111;
			y = 222;
			
			temp= x;
			x = y;
			y = temp;
			
			System.out.println("x="+ x + "y="+ y);
			
		}  
}
	
		
		


