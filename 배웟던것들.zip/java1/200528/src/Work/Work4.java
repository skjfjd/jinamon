package Work;

public class Work4 {

	public static void main(String[] args) {
			String str = "123";
			System.out.println(str + "는 숫자입니까? "+ isNumber(str));
			str="1234o";
			System.out.println(str + "는 숫자입니까? "+ isNumber(str));
	}
	static boolean isNumber(String num) {
	//	boolean b = true;
		
		for (int i = 0; i < num.length(); i++) {
			char c = num.charAt(i);
			int n = (char)c;
			if(n < 48 || n>57) { //숫자가 아니면 폴스 숫자면 트루 
			//	b= false;
			//	break;
				return false;
			}
			
		}
	//	return b;
		return true;
	}
}
