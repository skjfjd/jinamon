package Work;

public class Work2 {

	public static void main(String[] args) {

		int original[]= {1,2,3,4,5,6,7,8,9,};
		System.out.println(java.util.Arrays.toString(original)); //tostring 은 객체가 가지고 있는 정보나 값드을 문자열로 리턴
	//	int[] result = shuffle(original);
		 shuffle(original);
		System.out.println(java.util.Arrays.toString(original));

		 
	}
	
	
//	static int[] shuffle(int original[])
	static void shuffle(int original[]){
		int temp;
		
		for (int i = 0; i < 100; i++) { // 랜덤 값을 수행하기위한 loop문
			int r1 = (int)(Math.random()*original.length);// 0~8
			int r2 = (int)(Math.random()*original.length);// 0~8
			
			
			temp = original[r1];
			original[r1] = original[r2];
			original[r2] =temp;
			
		}
	//	return original;
		
	}
}
