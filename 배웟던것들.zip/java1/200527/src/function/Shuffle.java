package function;

import java.util.Scanner;

public class Shuffle {

	public static void main(String[] args) {
    //셔플 	반환타입 int[]  매개변수 int arr[]	
		
		int arr[] = new int[10];
		boolean swit[]= new boolean[arr.length]; // swit 10개 생성 
		
		
		for (int i = 0; i < arr.length; i++) { //배열에 0 부터 ~ 9까지 순서대로 배열한다
			arr[i]=i;
			
			
		}
		System.out.println("\n섞기 전 : ");
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
		for (int i = 0; i < swit.length; i++) { //스위치 트루로 초기화
			swit[i]= true;
			
			
		}
		int w =0;
		int r;
		while(w<1) {
			r= (int)(Math.random()*arr.length); // 10개의 무작위로 주사위가 돌아간다
			if(swit[r]) {
				swit[r]=false;
				arr[w]=r;
				w++;
			}
			System.out.println("\n섞은후 : ");
			for (int i = 0; i < arr.length; i++) {
				System.out.print(arr[i] + " ");
			}
			
		}
		
		
	
	
		
		
	}
	
		
			
			
		
}
