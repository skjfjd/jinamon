package function;

import java.util.Scanner;

public class Cal {

	public static void main(String[] args) {
	//	Scanner sc = new Scanner(System.in);
		
		// 계산기  선언부
		int num1, num2;
		String oper;
		int result = 0;
		
		String strNum1, strNum2; //입력 변수
		
		// TODO: 입력
		strNum1 = numberInput("첫번째 수");
		/*
		while(true) {
			System.out.print("첫번째 수 = ");
			strNum1 = sc.next();
			boolean b = numberOk(strNum1);
			if(b == true) {
				System.out.println("숫자가 아닙니다. 다시 입력해 주십시오");
				continue;
			}
			break;
		}*/
		
	//	System.out.print("(+, -, *, /) = ");
	//	oper = sc.next();
		oper = operatorInput();	  //연산자 입력 버튼
		//System.out.print("두번째 수 = ");
		//num2 = sc.nextInt();
		strNum2 = numberInput("두번째 수");
						
		// 문자열 -> 숫자
		num1 = Integer.parseInt(strNum1);   
		num2 = Integer.parseInt(strNum2);
		
		// TODO: 계산
		result = calProcess(num1, num2, oper);
		/*
		switch (oper) {
			case "+":
				result = num1 + num2;
				break;
			case "-":
				result = num1 - num2;
				break;	
			case "*":
				result = num1 * num2;
				break;	
			case "/":
				result = num1 / num2;
				break;	
		}
		*/
		
		// TODO: 결과
		System.out.println(num1 + " " + oper + " " + num2 + " = " + result);
		
	}	
	static String operatorInput() {
		Scanner sc = new Scanner(System.in);
		String oper;
		while(true) {  // true 이용해 무한반복 시전
			System.out.println("(+ , - , * , /) = ");  // 연산자 값은 oper 입력
			oper = sc.next();
			if(oper.equals("+") || oper.equals("-") == true || oper.contentEquals("*") == true || oper.contentEquals("/") ==true) {
				break;  // + - * / 를 입력을 제대로하면  break; 로 인하여 다음으로 넘어감
			}
			System.out.println("잘못입력하셨습니다. 다시 입력해 주십시오."); //잘못입력하면 true 인해 무한 반복
		}
		return oper; //oper 로 반환
	}
	
	static String numberInput(String num12) { // 입력 받을 변수  num12? 가 하는 역할?
		Scanner sc = new Scanner(System.in);
		String strNum1; //선언
		while(true) {  //숫자가 아닐경우 계속 다시 입력창 실행
			System.out.print(num12 + " = ");  // ? 
			strNum1 = sc.next();  // 입력 신호
			boolean b = numberOk(strNum1); //strNum1 이 숫자인지 아닌지 판별
			if(b == true) { // 문자로 입력하면 숫자가 아니라 오류 발생
				System.out.println("숫자가 아닙니다. 다시 입력해 주십시오");
				continue;  //문자를 입력하면 다시 무한반복
			}
			break; //숫자가 맞으면 다음으로
		}
		return strNum1; //입력신호로 리턴
	}
	
	static boolean numberOk(String snum) { //문자열 중에 숫자를 판별 
		boolean noNumber = false; //noNumber 초기화
		for (int i = 0; i < snum.length(); i++) { //snum 문자열
			char c = snum.charAt(i);  //charAT 문자 로 리턴
			if((int)c < 48 || (int)c > 57) { // 1 ~ 9 
				noNumber = true; //거짓
				break;
			}
		}
		return noNumber; // return : true(숫자가 아님) false (모두 숫자)
	}
	
	static int calProcess(int n1, int n2, String oper) {	//연산자
		int r = 0;
		switch (oper) {
			case "+":
				r = n1 + n2;
				break;
			case "-":
				r = n1 - n2;
				break;	
			case "*":
				r = n1 * n2;
				break;	
			case "/":
				r = n1 / n2;
				break;	
		}
		return r;  //연산자를 r로 리턴( n1 , n2 , oper)
	}
	

}







