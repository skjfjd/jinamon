package main;

public class MainClass {
	
	public static void main(String[] args) {
		/*
		 Operator
		+ , - , / , * , %
		/ : ��
		%: ���� ������
		*/
		
		int num1 , num2;
		
		int result;
		
		num1 = 10;
		num2 = 20; //�и� 0�� ������ ����
		
		result = num1 + num2 ;
		System.out.println(num1 +" + " + num2 +  " = " + result);
		
		result = num1 - num2 ;
		System.out.println(num1 +" - " + num2 +  " = " + result);
		
		result = num1 * num2 ; 								                 // " + " ���̱� 
		System.out.println(num1 +" * " + num2 +  " = " + result);
		
		result = num1 / num2 ;
		System.out.println(num1 +" / " + num2 +  " = " + result);
		
		result = num1 % num2 ;
		System.out.println(num1 +" % " + num2 +  " = " + result);
		
		
		int number = 0;
		
		number = number + 1;
		number +=1;
		
		//increment (����������) ++
		//decrement (���ҿ�����) --
		
		number++;
		++number;
		number--;
		--number;
		
		System.out.println(" number= " + number );
		
		
		int tag;
		
		tag = ++number; // number = 3  tag = 3
		
		
		System.out.println(" number = " + number); 
		System.out.println(" tag = " + tag);
	
		
		tag = number++; // number = 4  tag = 3   //tag ���� �����ϰ�  number �� ȥ�ڸ� ++ �ϴ� ���
		
		System.out.println(" number = " + number); 
		System.out.println(" tag = " + tag);
		
		tag = (number++); // number =5  tag = 4
		System.out.println(" number = " + number); 
		System.out.println(" tag = " + tag);
		
	}
} 
