package Sort;

import java.util.Scanner;

public class SortinTest {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		
			int number[] = null;
			int count;
			boolean updown = false ; //판별

			//정렬할 갯수;
			System.out.println("정렬할 갯수는  :");
			count = sc.nextInt(); // 카운트로 입력을 받음
			// 1보다 커야 함
			
			// 정렬할 숫자를 동적 할당
			number = new int[count]; //카운트(입력신호)가 넘버로 입력을 옮김
			
			// 정렬할 숫자를 입력
			for (int i = 0; i < number.length; i++) { //0 번쨰 부터  number(입력값 까지) i++
				System.out.println((i+1) + "번째 수 : "); // i+1 해야  처음에 1번째 수 가 실행
				number[i] = sc.nextInt();   			// number 가 입력인데  number[i] i 번쨰부터 number.length(입력하고싶은숫자까지)
				
			}
			
			//오름(1) /내림(2)
			
			System.out.println("오름(1)/내림(2) = ");
			int ud = sc.nextInt();
			updown = (ud == 1)?true:false; //삼항연산자
			
			//정렬
			int temp;
			for (int i = 0; i < number.length-1; i++) {
				for (int j = i+1; j < number.length; j++) {
					
					if(updown) { //오름
						if(number[i]> number[j]) {
							temp = number[i];
							number[i]=number[j];  //number 입력하는 변수 number[i] 는 입력번호
							number[j]=temp;
						}
					}else {//내림
						if(number[i]< number[j]) {
							temp = number[i];
							number[i]=number[j];
							number[j]=temp;
					}
				}
			}
			
			
	}
					//결과
			String msg = "";
			if(updown) msg = "오름";
			else 	   msg = "내림";
			System.out.println(msg +"차순으로 정렬하였으며,");
			for (int i = 0; i < number.length; i++) {
				System.out.println(i + ":" + number[i]);
				
			}
			
			
			
			
}
}
