package ArrayEx;

public class Fibonnaci {

	public static void main(String[] args) {
			
		
		//�Ǻ���ġ
		// 0 1 1  2 3 5 8 13 21 34
		//  a b c
		//   a b c
		// loop 30ȸ
		
		long a,b,c;
		long arrNum[]= new long[30];
		
		int w = 0;
		
		//�ʱ� ��
		a = 0;
		b = 1;
		
		arrNum[0] = a;
		arrNum[1] = b;
		
		while(w<28) {
			
		
		c= a + b ;
		arrNum[w+2]  = c;
		
		
		//���� ����
		
		a = b;
		b = c;
		w++;
		}
		for (int i = 0; i < arrNum.length; i++) {
			System.out.print(arrNum[i] + " ");
		}
		System.out.println();
	}

}
