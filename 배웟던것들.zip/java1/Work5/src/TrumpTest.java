
public class TrumpTest {

	public static void main(String[] args) {
		
		
		int number[] = new int[52]; //���� ��ȣ
		boolean swit[] = new boolean[52]; // �ߺ� üũ
		
		int r , w;
		
		// init
	
		for (int i = 0; i < swit.length; i++) {
			swit[i] = false;
			
		}
		w=0;
		
		// 0~51  > 1~52
		// ���� , ����(ȿ��) , Ʈ�� , Ž��(�ӵ�)
		while(w < 52) {
		r = (int)(Math.random() *52);
		if(swit[r]==false) {
			swit[r]=true;
			number[w] = r;
			w++;
		}for (int i = 0; i < number.length; i++) {
			System.out.println(number[i]);
		
			}
				
			int cardNum; // 1~13
			int cardPic; // 0~3     0:�����̵�  1:���̾�  2:��Ʈ  3:Ŭ�ι�
			
		// ����
			
			
		
			
			for (int i = 0; i < number.length; i++) {
				
				cardNum = number[i] % 13 + 1; // 1 ~13
				
			if(cardNum== 1) {
				System.out.print("card number : " + number[i] + ", " + "A");
			}else if(cardNum ==11) {  //J
				System.out.print("card number : " + number[i] + ", " + "j");
			}else if(cardNum ==12) { //Q
				System.out.print("card number : " + number[i] + ", " + "Q");
			}else if(cardNum ==13) { //K
				System.out.print("card number : " + number[i] + ", " + "K");
			}else { // �׿��� ��
				System.out.print("card number : " + number[i] + ", " + cardNum);
			}
		//	System.out.println();
			cardPic = number[i] /13; // 0~3
			
			switch(cardPic) {
				case 0:
					System.out.println(",  �����̵�");
					break;
				case 1:
					System.out.println(",  ���̾�");
					break;
				case 2:
					System.out.println(",  ��Ʈ");
					break;
				case 3:
					System.out.println(",  Ŭ�ι�");
					break;
			}
			}
			
			}
		// �׸�
			
			
			
			
			
			
			

		
		
		
		
}
}