import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		/* 
		 		 
		  	�Է� : input
		  	
		  	���: output  -> �ܼ� text 
		  		 System.out.println();
		  		 
		  	�Է� -> ������ ���� ����(����)
		 */
		Scanner scan = new Scanner(System.in);
		
		// boolean (true/false)
		boolean b;
		System.out.println("b =");
		b= scan.nextBoolean(); //true /false
		System.out.println("b:" +b);
		// int (����)
		
		int number;
		System.out.println("number = ");
		number = scan.nextInt();
		
		System.out.println("number:" + number);
		// double (�Ǽ�)
		double d;
		System.out.println("d = " );
		d= scan.nextDouble();
		System.out.println("d = " + d);
	
		
		scan.nextLine();
		
		// String (���ڿ�)
							//next , nextln
		String _str;
		System.out.println("_str=");
		_str =scan.nextLine();
		System.out.println("_str=" +_str);
		
		
		String str;
		System.out.print("str = ");
		str = scan.next();
		System.out.println("str="+ str);
		
		// ' ' == null ����(����)
		
		
	}
}
