package bj;

import java.util.ArrayList;

public class Deck {
		ArrayList<card> list = new ArrayList<card>();
		
		
		
		
}
