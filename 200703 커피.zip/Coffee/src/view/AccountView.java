package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class AccountView extends JFrame implements ActionListener{

	private JTextField idTextF;
	private JTextField pwTextF;
	private JTextField nameTextF;
	private JTextField ageTextF;
	
	JButton idBtn, loginBtn;
	public  AccountView() {
		super("회원가입 페이지");
		setLayout(null);
		
		JLabel upLabel = new JLabel("회원 가입");
		upLabel.setBounds(30, 10, 220, 70);
		upLabel.setFont(upLabel.getFont().deriveFont(20.0f));
		upLabel.setFont(new Font("Serif", Font.BOLD, 20));
		add(upLabel);
		
		
		idTextF = new  JTextField("ID");
		idTextF.setBounds(70,100,230,23);
		add(idTextF);
		
		
	    idBtn = new JButton("ID 확인");
		idBtn.setBounds(310, 100, 80, 23);
		add(idBtn);
		
		pwTextF = new JTextField("Password");
		pwTextF.setBounds(70, 140, 230, 23);
		add(pwTextF);
		
		nameTextF = new JTextField("이름");
		nameTextF.setBounds(70, 180, 230, 23);
		add(nameTextF);
		
		ageTextF = new JTextField("나이");
		ageTextF.setBounds(70, 220, 230, 23);
		add(ageTextF);
		
		loginBtn = new JButton("회원가입");
		loginBtn.setBounds(120, 280, 150, 50);
		loginBtn.setFont(loginBtn.getFont().deriveFont(17.0f));
		loginBtn.setBackground(new Color(0,100,200));
		loginBtn.addActionListener(this);
		add(loginBtn);
		
		
		
		setBounds(100, 100, 450, 400);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	
	
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
			
	}

}
