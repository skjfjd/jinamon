package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.text.StyledEditorKit.ItalicAction;

public class LoginView extends JFrame implements ActionListener {
	
	private JTextField idTextF;
	private JTextField pwTextF;
	
	private JButton logBtn;
	private JButton accountBtn;
	
	
	
	public  LoginView() {
		super("로그인 화면");
			setLayout(null);
		JLabel upLabel = new JLabel(" Coffee Prince Song ~");
		upLabel.setBounds(20, 20, 220, 100);
		upLabel.setFont(upLabel.getFont().deriveFont(20.0f));
		upLabel.setFont(new Font("Serif", Font.BOLD, 20));
		add(upLabel);
			
		
		idTextF = new JTextField("ID ");
		idTextF.setBounds(100, 120, 240, 30);
		add(idTextF);
		
		JLabel idLabel = new JLabel("ID : ");
		idLabel.setBounds(65, 120, 30, 30);
		add(idLabel);
		
		pwTextF = new JTextField("Password ");
		pwTextF.setBounds(100, 170, 240, 30);
		add(pwTextF);
		
		JLabel pwLabel = new JLabel("Password :");
		pwLabel.setBounds(20, 170, 70, 30);
		add(pwLabel);
		
		logBtn = new JButton("로그인");
		logBtn.setBounds(65, 250, 130, 40);
		logBtn.setBackground(new Color(0,100,200));
		add(logBtn);
		
		accountBtn = new JButton("회원가입");
		accountBtn.setBounds(210, 250, 130, 40);
		accountBtn.addActionListener(this);
		accountBtn.setBackground(new Color(0,100,200));
		add(accountBtn);
		
		JPanel jp = new JPanel();
		jp.setBounds(100, 100, 480, 600);
		add(jp);
		
		
		
		
		setBounds(100, 100, 450, 400);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		
	}	
	
	
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		JButton btn = (JButton)e.getSource();
		
		if(btn==accountBtn) {
			new AccountView();
			this.dispose();
		}
	}

}
