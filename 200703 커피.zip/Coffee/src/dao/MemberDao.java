package dao;

public class MemberDao {

}
