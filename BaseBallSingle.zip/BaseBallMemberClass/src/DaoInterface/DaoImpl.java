package DaoInterface;

public interface DaoImpl {

	public void process();
}
