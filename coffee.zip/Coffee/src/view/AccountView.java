package view;

import java.awt.Color;
import java.awt.Font;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import dao.MemberDao;
import dto.MemberDto;

public class AccountView extends JFrame implements ActionListener{

	private JTextField idTextF;
	private JTextField pwTextF;
	private JTextField nameTextF;
	private JTextField ageTextF;
	
	
	JButton idBtn, loginBtn;
	
	
	
	
	
	
	public  AccountView() {
		super("회원가입 페이지");
		
		setLayout(null);
		
		JLabel upLabel = new JLabel("회원 가입");
		upLabel.setBounds(30, 10, 220, 70);
		upLabel.setFont(upLabel.getFont().deriveFont(20.0f));
		upLabel.setFont(new Font("Serif", Font.BOLD, 20));
		add(upLabel);
		
		
		idTextF = new  JTextField();
		idTextF.setBounds(70,100,230,23);
		add(idTextF);
		
		
	    idBtn = new JButton("ID 확인");
		idBtn.setBounds(310, 100, 80, 23);
		idBtn.addActionListener(this);
		add(idBtn);
		
		pwTextF = new JTextField();
		pwTextF.setBounds(70, 140, 230, 23);
		add(pwTextF);
		
		nameTextF = new JTextField();
		nameTextF.setBounds(70, 180, 230, 23);
		add(nameTextF);
		
		ageTextF = new JTextField();
		ageTextF.setBounds(70, 220, 230, 23);
		add(ageTextF);
		
		loginBtn = new JButton("회원가입");
		loginBtn.setBounds(120, 280, 150, 50);
		loginBtn.setFont(loginBtn.getFont().deriveFont(17.0f));
		loginBtn.setBackground(new Color(0,100,200));
		loginBtn.addActionListener(this);
		add(loginBtn);
		
		JLabel idLabel = new JLabel("아이디 : ");
		idLabel.setBounds(20, 85, 50, 50);
		add(idLabel);
		
		JLabel pwLabel = new JLabel("비밀번호 : ");
		pwLabel.setBounds(10, 126, 70, 50);
		add(pwLabel);
		
		JLabel nameLabel = new JLabel("이름 : ");
		nameLabel.setBounds(35, 166, 70, 50);
		add(nameLabel);
		
		JLabel ageLabel = new JLabel("나이 : ");
		ageLabel.setBounds(35, 206, 70, 50);
		add(ageLabel);
		
	
		
		setBounds(100, 100, 450, 400);
		setBackground(new Color(120,100,100));
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
			JButton btn = (JButton)arg0.getSource();
			String btnTitle = btn.getLabel();
			
		if(btnTitle.equals("ID 확인"))	{
			MemberDao dao = MemberDao.getInstance();
			
			String id = idTextF.getText().trim();
			boolean b = dao.getId(id);
			
		if(b== true) {
			JOptionPane.showMessageDialog(null, " 사용할수 없는 ID 입니다.");
			idTextF.setText("");
		}else {
			JOptionPane.showMessageDialog(null, " 이 ID 는 사용할수 있습니다.");
			
		}
		}
		else if(btnTitle.equals("회원가입")) {
			if(idTextF.getText().equals("")||
			pwTextF.getText().equals("")||
			nameTextF.getText().equals("")||
			ageTextF.getText().equals("")) {
				JOptionPane.showMessageDialog(null, " 모두 기입해 주십시오");
				return;
			}
			MemberDao dao = MemberDao.getInstance();
			
			
			boolean b =dao.addMember(new MemberDto(idTextF.getText(),pwTextF.getText(),nameTextF.getText(),ageTextF.getText(),0));
		if(b) {
			JOptionPane.showMessageDialog(null, "성공적으로 가입 되었습니다");
			this.dispose();
			new LoginView();
		}else {
			JOptionPane.showMessageDialog(null, "가입에 실패했습니다");
		}
		}
			
	}
}
