package Func;

import java.util.Scanner;

public class Sorting {

	public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			
			//선언부
			
			 int number[] = null;
			 int count;
			 boolean check = false;
			 
			 //정렬할 개수
			 
			 System.out.println("정렬할 갯수는 : ");
			 count = sc.nextInt();
			 
			 //정렬할 숫자를 동적할당
			 number = new int[count];
			 
			 //정렬할 숫자를 입력
			 for (int i = 0; i < number.length; i++) {
				 System.out.println((i+1)+ "번째 수 : ");
				number[i] =sc.nextInt();
			
					}
			// 1. 입력 (숫자들 , 오름/내림)
				
				System.out.println("오름(1)/내림(2) = ");
				int ud = sc.nextInt();
				check = (ud==1)?true:false;
				
				// 2. 처리 swap
				int temp;
				for (int i = 0; i < number.length-1; i++) {
					for (int j = i+1; j < number.length; j++) {
						if(check) {  //트루 이면 오름   (중요..)
							
							if(number[i]>number[j]) {
							temp=number[i];
							number[i]=number[j];
							number[j]=temp;
							
						}
						}else {//폴스면 내림
							if(number[i]<number[j]) {
								temp=number[i];
								number[i]=number[j];
								number[j]=temp;
							
							}
						}
					
					}
						
					}
					// 3. 출력 
					String msg = "";
					if(check) msg="오름";
					else      msg="내림";
					System.out.println(msg + "차순의 값은 ");
				for (int i = 0; i < number.length; i++) {
					System.out.println(i + ": "+ number[i] + " 이다");
				
				}
				



			
	}
			
			 
	

}
