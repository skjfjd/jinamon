package Func;

public class Func2 {

	public static void main(String[] args) {
			//가변인수
			//매개변수가 유동적이다
			//개발자
		allocParam(1,2,3,4,5);
		
		allocParam(23,36,75);
		
	}
	static void allocParam(int...num) {
		int sum = 0;
		for (int i = 0; i < num.length; i++) {
			sum = sum+num[i];
			
			
		}
		System.out.println("합계 : "  + sum);
		
	}
	static void func(String str , int...num) {  //가변인수는 맨 뒷부분에 와야함
		System.out.println("str : " + str);
		for (int i = 0; i < num.length; i++) {
			System.out.println(num[i] + " ");
			
		}
		System.out.println();
	}

}
