package Func;

public class baseballFunc {

	public static void main(String[] args) {
			/*
			 1. random
			 
			 2. userInput
			  
			 3. (finding)
			 
			 4. message
			  
			 */
	}

}
