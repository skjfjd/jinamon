package Func;

import java.util.Scanner;

public class Student {

	public static void main(String[] args) {
		/*
		 
		 	학생 성적 관리 
		  String student[][];
		  
		  메뉴-----
		  1. 학생 정보 추가  insert (예: 홍길동 , 나이  영어 ,수학)
		  2. 학생 정보 삭제  delete
		  3. 학생 정보 검색  search
		  4. 학생 정보 수정  update
		  5. 학생 정보 모두 출력
		  
		  6. 과목의 총점   1.영어
		  7. 과목의 평균
		  
		  8. 성적순 정렬 출력
		  
		  
		 */
		
		Scanner sc = new Scanner(System.in);
		
		String[][] student =new String[20][4];
		int choice;
		
		
	for (int i = 0; i < student.length; i++) {
		for (int j = 0; j < student[i].length; j++) {
			student[i][j]="";
		}
	}	
	
		
		while(true) {
		System.out.println("----------------메뉴 ");
		System.out.println(" 1. 학생 정보 추가  insert ");
		System.out.println("2. 학생 정보 삭제  delete ");
		System.out.println("3. 학생 정보 검색  search ");
		System.out.println("4. 학생 정보 수정  update ");
		System.out.println("5. 학생 정보 모두 출력 ");
			
		System.out.println("메뉴 번호를 입력해주십시오 ");
		System.out.print(">>");
		choice = sc.nextInt();
		
		switch(choice) {
		case 1:  //학생 추가
				insert(student);
			break;
		}
		}
		
		
	}
	static void insert(String student[][]) {
		Scanner sc = new Scanner(System.in);
		int findIndex= -1; //0 넣으면 안됨 0번쨰가 어쩌고 저쩌고
	
		for (int i = 0; i < student.length; i++) {
			if(student[i][0].equals("")){
				findIndex= i;
				break;
			}
		}
		System.out.println("findIndex : " + findIndex);
		
		System.out.println("이름:");
		String name = sc.next();
		
		System.out.println("나이:");
		String age = sc.next();
		
		System.out.print("영어:");
		String eng = sc.next();
		
		System.out.print("수학:");
		String math = sc.next();
		
		student[findIndex][0] = name;
		student[findIndex][1] = age;
		student[findIndex][2] = eng;
		student[findIndex][3] = math;
		
		System.out.println("입력 완료 : " +student[findIndex][0]);
	}
}
