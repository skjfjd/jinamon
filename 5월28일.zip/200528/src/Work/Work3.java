package Work;

public class Work3 {

	public static void main(String[] args) {
		
			
		
		int[] data = { 3,2,9,4,7 };
		System.out.println(java.util.Arrays.toString(data));
		int r = max(data);
		System.out.println("최대값:"+ r);
	}
	static int max(int data[]) {
		int max_num = data[0];
		
		for (int i = 0; i < data.length; i++) {
			if(max_num < data[i]) {
				max_num =data[i];
			}
		}
		return max_num;
		
		
	}

}
